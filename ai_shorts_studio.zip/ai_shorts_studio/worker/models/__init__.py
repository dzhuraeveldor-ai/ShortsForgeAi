"""
Pydantic models for AI Worker API.
"""

from datetime import datetime
from typing import Optional, Any
from pydantic import BaseModel, Field


# ============================================
# Job Models
# ============================================

class JobStatus:
    """Job status constants."""
    QUEUED = "queued"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class JobType:
    """Job type constants."""
    TEXT = "text"
    HOOKS = "hooks"
    IDEAS = "ideas"
    SCRIPT = "script"
    SCENES = "scenes"
    IMAGE = "image"
    VIDEO = "video"
    VOICE = "voice"
    SUBTITLES = "subtitles"
    RENDER = "render"
    ANALYZE = "analyze"
    SEO = "seo"


class JobRequest(BaseModel):
    """Request to create a new job."""
    job_type: str = Field(..., description="Type of job: text, hooks, ideas, script, scenes, image, video, voice, subtitles, render, analyze, seo")
    payload: dict[str, Any] = Field(default_factory=dict, description="Job-specific parameters")


class JobResponse(BaseModel):
    """Response with job status and result."""
    job_id: str
    job_type: str
    status: str
    progress: int = 0
    result: Optional[dict[str, Any]] = None
    error: Optional[str] = None
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


# ============================================
# Health Models
# ============================================

class HealthResponse(BaseModel):
    """Worker health status response."""
    status: str  # online / offline
    gpu: Optional[str] = None
    vram: Optional[str] = None
    models: dict[str, bool] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ============================================
# Service-specific payload models
# ============================================

class TextPayload(BaseModel):
    """Payload for text generation."""
    prompt: str
    system_prompt: Optional[str] = None
    max_tokens: int = 2048
    temperature: float = 0.7


class HooksPayload(BaseModel):
    """Payload for hooks generation."""
    niche: str
    content_type: str
    language: str = "american_english"
    count: int = 5


class IdeasPayload(BaseModel):
    """Payload for ideas generation."""
    niche: str
    content_type: str
    hook: Optional[str] = None
    language: str = "american_english"
    count: int = 5


class ScriptPayload(BaseModel):
    """Payload for script generation."""
    niche: str
    content_type: str
    idea: str
    hook: str
    duration: int
    language: str = "american_english"
    voice_style: str = "auto"


class ScenesPayload(BaseModel):
    """Payload for scene breakdown."""
    script: str
    duration: int
    visual_style: str
    niche: str


class ImagePayload(BaseModel):
    """Payload for image generation."""
    prompt: str
    negative_prompt: Optional[str] = None
    width: int = 576
    height: int = 1024
    num_inference_steps: int = 20


class VoicePayload(BaseModel):
    """Payload for voice generation."""
    text: str
    gender: str = "auto"
    style: str = "auto"
    language: str = "american_english"
    speed: float = 1.0


class SubtitlesPayload(BaseModel):
    """Payload for subtitle generation."""
    audio_path: str
    language: str = "auto"


class SEOPayload(BaseModel):
    """Payload for SEO metadata generation."""
    script: str
    niche: str
    content_type: str
    language: str = "american_english"
