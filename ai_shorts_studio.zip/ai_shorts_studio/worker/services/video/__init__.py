"""
Video generation service for AI Worker.
Interface for open-source video models (Wan, LTX-Video, CogVideoX).
Models are heavy and require manual setup.
"""

from pathlib import Path
from typing import Optional
from loguru import logger

from worker.config import config
from worker.services.model_manager import model_manager
from worker.utils import generate_id


class VideoService:
    """Service for AI video generation."""

    def __init__(self):
        self._available = False
        self._model_type: Optional[str] = None

    async def initialize(self) -> None:
        """Initialize video generation service."""
        # Video models require manual setup - we just report availability
        self._available = False  # Disabled by default, requires manual model download
        logger.info("🎥 VideoService: video models require manual setup (see README)")

    async def text_to_video(
        self,
        prompt: str,
        duration: int = 5,
        width: int = 576,
        height: int = 1024,
    ) -> dict:
        """Generate video from text prompt."""
        output_dir = config.TEMP_DIR / "video"
        output_dir.mkdir(parents=True, exist_ok=True)
        video_id = generate_id()
        output_path = output_dir / f"{video_id}.mp4"

        if not self._available:
            return self._create_fallback_video(output_path, prompt, duration, width, height)

        # Placeholder for real video model integration
        logger.warning("Video generation called but no model loaded")
        return self._create_fallback_video(output_path, prompt, duration, width, height)

    async def image_to_video(
        self,
        image_path: str,
        prompt: Optional[str] = None,
        duration: int = 3,
        motion_bucket_id: int = 127,
    ) -> dict:
        """Animate an image into video."""
        output_dir = config.TEMP_DIR / "video"
        output_dir.mkdir(parents=True, exist_ok=True)
        video_id = generate_id()
        output_path = output_dir / f"{video_id}.mp4"

        if not self._available:
            return self._create_ken_burns_video(Path(image_path), output_path, duration)

        return self._create_ken_burns_video(Path(image_path), output_path, duration)

    def _create_fallback_video(
        self,
        output_path: Path,
        prompt: str,
        duration: int,
        width: int,
        height: int,
    ) -> dict:
        """Create a simple placeholder video using FFmpeg."""
        try:
            import subprocess

            # Generate a colored background with text
            color_seed = abs(hash(prompt))
            color = f"{(color_seed & 0xFF):02x}{((color_seed >> 8) & 0xFF):02x}{((color_seed >> 16) & 0xFF):02x}"

            # Create a simple video with FFmpeg
            cmd = [
                config.FFMPEG_PATH, "-y",
                "-f", "lavfi",
                "-i", f"color=c=0x{color}:s={width}x{height}:d={duration}",
                "-vf", f"drawtext=text='AI Video Placeholder':fontsize=48:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2",
                "-c:v", "libx264",
                "-pix_fmt", "yuv420p",
                "-r", "30",
                str(output_path),
            ]

            subprocess.run(cmd, capture_output=True, timeout=30)

            return {
                "video_path": str(output_path),
                "duration": duration,
                "width": width,
                "height": height,
                "model": "ffmpeg_placeholder",
                "note": "Placeholder video - install video models for real AI generation",
            }
        except Exception as e:
            logger.error(f"Fallback video creation failed: {e}")
            output_path.touch()
            return {
                "video_path": str(output_path),
                "error": str(e),
                "model": "none",
            }

    def _create_ken_burns_video(
        self,
        image_path: Path,
        output_path: Path,
        duration: int = 3,
    ) -> dict:
        """Create a Ken Burns effect video from an image using FFmpeg."""
        try:
            import subprocess

            # Get image dimensions
            probe_cmd = [
                config.FFMPEG_PATH, "-v", "error",
                "-select_streams", "v:0",
                "-show_entries", "stream=width,height",
                "-of", "csv=p=0",
                str(image_path),
            ]
            probe = subprocess.run(probe_cmd, capture_output=True, text=True, timeout=5)
            if probe.returncode == 0 and probe.stdout.strip():
                w, h = probe.stdout.strip().split(",")
                width, height = int(w), int(h)
            else:
                width, height = 576, 1024

            # Ken Burns: slow zoom in
            cmd = [
                config.FFMPEG_PATH, "-y",
                "-loop", "1",
                "-i", str(image_path),
                "-filter_complex",
                f"[0:v]scale=-2:{height*2},zoompan=z='min(zoom+0.0015,1.5)':d={duration*30}:s={width}x{height}:fps=30[v]",
                "-map", "[v]",
                "-c:v", "libx264",
                "-pix_fmt", "yuv420p",
                "-t", str(duration),
                "-r", "30",
                str(output_path),
            ]

            subprocess.run(cmd, capture_output=True, timeout=60)

            if output_path.exists() and output_path.stat().st_size > 0:
                return {
                    "video_path": str(output_path),
                    "duration": duration,
                    "width": width,
                    "height": height,
                    "effect": "ken_burns_zoom",
                    "model": "ffmpeg_ken_burns",
                }

            return self._create_fallback_video(output_path, "ken_burns", duration, width, height)

        except Exception as e:
            logger.error(f"Ken Burns video creation failed: {e}")
            return self._create_fallback_video(output_path, "ken_burns_fallback", duration, 576, 1024)


# Global video service
video_service = VideoService()
