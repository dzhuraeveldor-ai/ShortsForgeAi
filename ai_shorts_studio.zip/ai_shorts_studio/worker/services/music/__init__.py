"""
Music selection service for AI Worker.
Automatically selects royalty-free music based on niche, content type, and emotion.
Uses generated sine-wave music as fallback when no audio files available.
"""

import math
import struct
import random
from pathlib import Path
from typing import Optional
from loguru import logger

from worker.config import config
from worker.utils import generate_id


# Music style profiles
MUSIC_PROFILES = {
    "horror": {
        "tempo": "slow",
        "scale": "minor_diminished",
        "instruments": ["ambient_pad", "low_bass"],
        "mood": "dark_suspense",
        "base_freq": 110,
    },
    "motivation": {
        "tempo": "fast",
        "scale": "major",
        "instruments": ["piano", "strings", "drums"],
        "mood": "energetic_uplifting",
        "base_freq": 220,
    },
    "luxury": {
        "tempo": "slow",
        "scale": "major_7th",
        "instruments": ["ambient_pad", "piano"],
        "mood": "elegant",
        "base_freq": 196,
    },
    "facts": {
        "tempo": "medium",
        "scale": "minor",
        "instruments": ["piano", "percussion"],
        "mood": "modern_documentary",
        "base_freq": 220,
    },
    "funny": {
        "tempo": "fast",
        "scale": "major",
        "instruments": ["ukulele", "percussion"],
        "mood": "light_playful",
        "base_freq": 330,
    },
    "science": {
        "tempo": "medium",
        "scale": "minor_pentatonic",
        "instruments": ["synth_pad", "arp"],
        "mood": "futuristic_ambient",
        "base_freq": 200,
    },
    "history": {
        "tempo": "medium",
        "scale": "minor",
        "instruments": ["strings", "piano"],
        "mood": "cinematic_documentary",
        "base_freq": 196,
    },
    "gaming": {
        "tempo": "fast",
        "scale": "minor",
        "instruments": ["synth", "drums", "bass"],
        "mood": "energetic_electronic",
        "base_freq": 147,
    },
    "animals": {
        "tempo": "medium",
        "scale": "major",
        "instruments": ["piano", "strings"],
        "mood": "playful_emotional",
        "base_freq": 262,
    },
    "mystery": {
        "tempo": "slow",
        "scale": "minor_diminished",
        "instruments": ["ambient_pad"],
        "mood": "suspense",
        "base_freq": 165,
    },
    "ai": {
        "tempo": "medium",
        "scale": "minor_pentatonic",
        "instruments": ["synth_pad", "arp"],
        "mood": "futuristic_electronic",
        "base_freq": 220,
    },
    "storytelling": {
        "tempo": "medium",
        "scale": "minor",
        "instruments": ["piano", "strings"],
        "mood": "cinematic_storytelling",
        "base_freq": 220,
    },
    "money": {
        "tempo": "medium",
        "scale": "major",
        "instruments": ["piano", "bass"],
        "mood": "corporate_ambitious",
        "base_freq": 220,
    },
    "space": {
        "tempo": "slow",
        "scale": "minor_pentatonic",
        "instruments": ["ambient_pad", "arp"],
        "mood": "cosmic_ambient",
        "base_freq": 175,
    },
    "technology": {
        "tempo": "medium",
        "scale": "minor",
        "instruments": ["synth", "percussion"],
        "mood": "modern_electronic",
        "base_freq": 220,
    },
    "education": {
        "tempo": "medium",
        "scale": "major",
        "instruments": ["piano", "light_strings"],
        "mood": "light_documentary",
        "base_freq": 262,
    },
    "sports": {
        "tempo": "fast",
        "scale": "minor",
        "instruments": ["drums", "bass", "brass"],
        "mood": "energetic_driving",
        "base_freq": 165,
    },
}

# Musical scales (semitone intervals from root)
SCALES = {
    "major": [0, 2, 4, 5, 7, 9, 11, 12],
    "minor": [0, 2, 3, 5, 7, 8, 10, 12],
    "major_7th": [0, 2, 4, 5, 7, 9, 11, 11],
    "minor_diminished": [0, 2, 3, 5, 6, 8, 9, 11],
    "minor_pentatonic": [0, 3, 5, 7, 10, 12],
}


class MusicService:
    """Service for automatic music selection and generation."""

    def __init__(self):
        self._music_library: dict[str, list[Path]] = {}
        self._scan_library()

    def _scan_library(self) -> None:
        """Scan music library directory for royalty-free tracks."""
        music_dir = config.STORAGE_DIR / "music"
        music_dir.mkdir(parents=True, exist_ok=True)

        # Scan for audio files
        for ext in ["*.mp3", "*.wav", "*.ogg", "*.flac"]:
            for f in music_dir.rglob(ext):
                category = f.parent.name if f.parent != music_dir else "general"
                if category not in self._music_library:
                    self._music_library[category] = []
                self._music_library[category].append(f)

        total = sum(len(v) for v in self._music_library.values())
        logger.info(f"🎵 MusicService: found {total} tracks in library")

    def select_music_style(self, niche: str, content_type: str) -> str:
        """Select appropriate music style based on niche and content type."""
        niche_lower = niche.lower()

        # Try exact niche match
        for key in MUSIC_PROFILES:
            if key in niche_lower:
                return key

        # Try content type
        ct_lower = (content_type or "").lower()
        for key in MUSIC_PROFILES:
            if key in ct_lower:
                return key

        # Default
        return "storytelling"

    async def generate_music(
        self,
        style: str,
        duration: float,
        target_path: Optional[Path] = None,
    ) -> dict:
        """Generate or select music for the given style and duration."""
        if target_path is None:
            output_dir = config.TEMP_DIR / "music"
            output_dir.mkdir(parents=True, exist_ok=True)
            music_id = generate_id()
            target_path = output_dir / f"{music_id}.wav"

        # Check if we have a real track in library
        library_tracks = self._music_library.get(style, [])
        if not library_tracks:
            library_tracks = self._music_library.get("general", [])

        if library_tracks:
            selected = random.choice(library_tracks)
            result = self._process_library_track(selected, target_path, duration, style)
            return result

        # Generate procedural music
        profile = MUSIC_PROFILES.get(style, MUSIC_PROFILES["storytelling"])
        return self._generate_procedural_music(target_path, duration, profile, style)

    def _process_library_track(
        self,
        source_path: Path,
        target_path: Path,
        duration: float,
        style: str,
    ) -> dict:
        """Process a library track: trim, loop, fade to target duration."""
        try:
            import subprocess

            # Use FFmpeg to trim/loop and add fades
            fade_duration = min(1.0, duration * 0.1)

            cmd = [
                config.FFMPEG_PATH, "-y",
                "-i", str(source_path),
                "-filter_complex",
                f"aloop=loop=-1:size=2e+09,atrim=0:{duration},afade=t=in:st=0:d={fade_duration},afade=t=out:st={duration - fade_duration}:d={fade_duration}",
                "-c:a", "pcm_s16le",
                str(target_path),
            ]

            subprocess.run(cmd, capture_output=True, timeout=30)

            if target_path.exists() and target_path.stat().st_size > 0:
                return {
                    "audio_path": str(target_path),
                    "source": str(source_path),
                    "style": style,
                    "duration": duration,
                    "format": "wav",
                }
        except Exception as e:
            logger.warning(f"Library track processing failed: {e}")

        # Fallback to procedural
        profile = MUSIC_PROFILES.get(style, MUSIC_PROFILES["storytelling"])
        return self._generate_procedural_music(target_path, duration, profile, style)

    def _generate_procedural_music(
        self,
        target_path: Path,
        duration: float,
        profile: dict,
        style: str,
    ) -> dict:
        """Generate procedural ambient music using sine waves."""
        sample_rate = 44100
        num_samples = int(duration * sample_rate)
        base_freq = profile.get("base_freq", 220)
        scale_name = profile.get("scale", "minor")
        scale = SCALES.get(scale_name, SCALES["minor"])

        # Generate audio
        audio_data = bytearray()

        # Tempo mapping
        tempo_map = {"slow": 0.8, "medium": 1.0, "fast": 1.4}
        tempo = tempo_map.get(profile.get("tempo", "medium"), 1.0)
        note_duration = 0.5 / tempo  # seconds per note

        random.seed(hash(style) & 0xFFFFFFFF)

        for i in range(num_samples):
            t = i / sample_rate
            sample = 0.0

            # Drone / pad note (root)
            drone = math.sin(2 * math.pi * base_freq * t) * 0.15

            # Melody notes
            note_index = int(t / note_duration) % len(scale)
            note_semitone = scale[note_index]
            note_freq = base_freq * (2 ** (note_semitone / 12))

            # Note envelope (attack-release)
            note_phase = (t % note_duration) / note_duration
            envelope = self._note_envelope(note_phase)

            melody = math.sin(2 * math.pi * note_freq * t) * 0.12 * envelope

            # Higher octave harmony
            harmony = math.sin(2 * math.pi * note_freq * 2 * t) * 0.05 * envelope

            # Subtle bass
            bass = math.sin(2 * math.pi * base_freq * 0.5 * t) * 0.1

            # Slow LFO for ambient feel
            lfo = 0.5 + 0.5 * math.sin(2 * math.pi * 0.1 * t)

            sample = drone + melody + harmony + bass
            sample *= (0.7 + 0.3 * lfo)

            # Fade in/out
            fade_in = min(1.0, t / 1.5)
            fade_out = min(1.0, max(0.0, (duration - t) / 2.0))
            sample *= fade_in * fade_out

            # Clamp and convert to 16-bit PCM
            sample = max(-1.0, min(1.0, sample))
            sample_int = int(sample * 32767)
            audio_data.extend(struct.pack("<h", sample_int))

        # Write WAV file
        self._write_wav(target_path, bytes(audio_data), sample_rate)

        return {
            "audio_path": str(target_path),
            "style": style,
            "duration": duration,
            "mood": profile.get("mood", "ambient"),
            "generation": "procedural_sine",
            "format": "wav",
            "note": "Procedurally generated ambient music",
        }

    def _note_envelope(self, phase: float) -> float:
        """Simple attack-release envelope."""
        if phase < 0.1:
            return phase / 0.1  # Attack
        elif phase > 0.7:
            return max(0.0, (1.0 - phase) / 0.3)  # Release
        return 1.0  # Sustain

    def _write_wav(self, path: Path, audio_bytes: bytes, sample_rate: int = 44100) -> None:
        """Write PCM audio as WAV file."""
        import struct

        num_frames = len(audio_bytes) // 2
        byte_rate = sample_rate * 2

        with open(path, "wb") as f:
            f.write(b"RIFF")
            f.write(struct.pack("<I", 36 + len(audio_bytes)))
            f.write(b"WAVE")
            f.write(b"fmt ")
            f.write(struct.pack("<I", 16))
            f.write(struct.pack("<H", 1))  # PCM
            f.write(struct.pack("<H", 1))  # Mono
            f.write(struct.pack("<I", sample_rate))
            f.write(struct.pack("<I", byte_rate))
            f.write(struct.pack("<H", 2))  # Block align
            f.write(struct.pack("<H", 16))  # Bits per sample
            f.write(b"data")
            f.write(struct.pack("<I", len(audio_bytes)))
            f.write(audio_bytes)


# Global music service
music_service = MusicService()
