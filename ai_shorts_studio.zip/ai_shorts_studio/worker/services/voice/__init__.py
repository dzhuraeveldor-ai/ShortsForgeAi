"""
Voice / TTS generation service for AI Worker.
Uses Piper TTS when available.
"""

import subprocess
import tempfile
from pathlib import Path
from typing import Optional
from loguru import logger

from worker.config import config
from worker.services.model_manager import model_manager
from worker.utils import generate_id


class VoiceService:
    """Service for text-to-speech generation."""

    def __init__(self):
        self._available = False
        self._engine = "none"

    async def initialize(self) -> None:
        """Initialize TTS engine."""
        # Check Piper
        try:
            import piper  # noqa: F401
            self._available = True
            self._engine = "piper"
            logger.info("🎙 VoiceService: using Piper TTS")
            return
        except ImportError:
            pass

        # Check kokoro
        try:
            import kokoro  # noqa: F401
            self._available = True
            self._engine = "kokoro"
            logger.info("🎙 VoiceService: using Kokoro TTS")
            return
        except ImportError:
            pass

        # Check espeak as last resort
        try:
            result = subprocess.run(["espeak", "--version"], capture_output=True, timeout=3)
            if result.returncode == 0:
                self._available = True
                self._engine = "espeak"
                logger.info("🎙 VoiceService: using eSpeak")
                return
        except Exception:
            pass

        logger.warning("🎙 VoiceService: no TTS engine available")

    @property
    def available(self) -> bool:
        """Check if TTS is available."""
        return self._available

    async def generate_voice(
        self,
        text: str,
        gender: str = "auto",
        style: str = "auto",
        language: str = "american_english",
        speed: float = 1.0,
    ) -> dict:
        """Generate voice audio from text."""
        output_dir = config.TEMP_DIR / "voice"
        output_dir.mkdir(parents=True, exist_ok=True)
        voice_id = generate_id()
        output_path = output_dir / f"{voice_id}.wav"

        if not self._available:
            return self._create_silent_audio(output_path, text)

        try:
            if self._engine == "piper":
                return await self._generate_piper(text, language, gender, speed, output_path)
            elif self._engine == "kokoro":
                return await self._generate_kokoro(text, language, gender, speed, output_path)
            elif self._engine == "espeak":
                return await self._generate_espeak(text, language, speed, output_path)
        except Exception as e:
            logger.error(f"TTS generation failed: {e}")
            return self._create_silent_audio(output_path, text)

        return self._create_silent_audio(output_path, text)

    async def _generate_piper(
        self,
        text: str,
        language: str,
        gender: str,
        speed: float,
        output_path: Path,
    ) -> dict:
        """Generate voice using Piper TTS."""
        from piper import PiperVoice

        # Determine voice model
        voice_model = config.PIPER_VOICE
        if not voice_model:
            # Default voices
            if "russian" in language.lower():
                voice_model = "ru_RU-irina-medium"
            elif gender == "male":
                voice_model = "en_US-ryan-medium"
            else:
                voice_model = "en_US-amy-medium"

        # Load voice
        voice = PiperVoice.load(voice_model)

        # Generate audio
        wav_bytes = b""
        for audio_bytes in voice.synthesize_stream_raw(text):
            wav_bytes += audio_bytes

        # Write WAV file
        self._write_wav(output_path, wav_bytes, sample_rate=22050)

        # Apply speed adjustment if needed
        if abs(speed - 1.0) > 0.05:
            output_path = self._adjust_speed(output_path, speed)

        return {
            "audio_path": str(output_path),
            "engine": "piper",
            "voice": voice_model,
            "language": language,
            "gender": gender,
            "speed": speed,
            "text_length": len(text),
            "format": "wav",
        }

    async def _generate_kokoro(
        self,
        text: str,
        language: str,
        gender: str,
        speed: float,
        output_path: Path,
    ) -> dict:
        """Generate voice using Kokoro TTS."""
        logger.info("🎙 Kokoro TTS generation (placeholder implementation)")
        return self._create_silent_audio(output_path, text)

    async def _generate_espeak(
        self,
        text: str,
        language: str,
        speed: float,
        output_path: Path,
    ) -> dict:
        """Generate voice using eSpeak."""
        lang_map = {
            "american_english": "en-us",
            "british_english": "en-gb",
            "russian": "ru",
        }
        espeak_lang = lang_map.get(language, "en-us")
        speed_wpm = int(175 * speed)

        result = subprocess.run(
            ["espeak", "-v", espeak_lang, "-s", str(speed_wpm), "-w", str(output_path), text],
            capture_output=True,
            timeout=30,
        )

        if result.returncode != 0:
            raise RuntimeError(f"eSpeak failed: {result.stderr.decode()}")

        return {
            "audio_path": str(output_path),
            "engine": "espeak",
            "language": language,
            "speed": speed,
            "text_length": len(text),
            "format": "wav",
        }

    def _write_wav(self, path: Path, audio_bytes: bytes, sample_rate: int = 22050, channels: int = 1, sample_width: int = 2) -> None:
        """Write raw PCM audio as WAV file."""
        import struct

        num_frames = len(audio_bytes) // sample_width
        byte_rate = sample_rate * channels * sample_width
        block_align = channels * sample_width

        with open(path, "wb") as f:
            # RIFF header
            f.write(b"RIFF")
            f.write(struct.pack("<I", 36 + len(audio_bytes)))
            f.write(b"WAVE")
            # fmt chunk
            f.write(b"fmt ")
            f.write(struct.pack("<I", 16))
            f.write(struct.pack("<H", 1))  # PCM
            f.write(struct.pack("<H", channels))
            f.write(struct.pack("<I", sample_rate))
            f.write(struct.pack("<I", byte_rate))
            f.write(struct.pack("<H", block_align))
            f.write(struct.pack("<H", sample_width * 8))
            # data chunk
            f.write(b"data")
            f.write(struct.pack("<I", len(audio_bytes)))
            f.write(audio_bytes)

    def _adjust_speed(self, audio_path: Path, speed: float) -> Path:
        """Adjust audio speed using FFmpeg."""
        try:
            output_path = audio_path.with_name(audio_path.stem + f"_spd{speed}.wav")
            subprocess.run(
                [
                    config.FFMPEG_PATH, "-y", "-i", str(audio_path),
                    "-filter:a", f"atempo={speed}",
                    str(output_path),
                ],
                capture_output=True, timeout=30,
            )
            if output_path.exists():
                return output_path
        except Exception as e:
            logger.warning(f"Speed adjustment failed: {e}")
        return audio_path

    def _create_silent_audio(self, output_path: Path, text: str) -> dict:
        """Create a short silent audio file as fallback."""
        try:
            # Calculate duration based on text length (~150 wpm)
            word_count = len(text.split())
            duration_seconds = max(1.0, word_count / 150 * 60)

            # Generate silence using FFmpeg
            subprocess.run(
                [
                    config.FFMPEG_PATH, "-y", "-f", "lavfi",
                    "-i", f"anullsrc=r=22050:cl=mono:d={duration_seconds}",
                    str(output_path),
                ],
                capture_output=True, timeout=10,
            )

            return {
                "audio_path": str(output_path),
                "engine": "silent_fallback",
                "note": "Silent audio - install piper-tts for real voice generation",
                "duration": duration_seconds,
                "format": "wav",
            }
        except Exception as e:
            logger.error(f"Silent audio creation failed: {e}")
            output_path.touch()
            return {
                "audio_path": str(output_path),
                "engine": "none",
                "error": str(e),
                "format": "wav",
            }


# Global voice service
voice_service = VoiceService()
