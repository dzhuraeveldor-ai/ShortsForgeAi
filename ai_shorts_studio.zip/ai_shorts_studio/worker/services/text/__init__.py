"""
Text generation service for AI Worker.
Uses Ollama for LLM-based text generation with fallback templates.
"""

import json
import random
from typing import Optional
from loguru import logger

from worker.config import config
from worker.services.model_manager import model_manager


class TextService:
    """Service for all text generation tasks."""

    def __init__(self):
        self._ollama_available = False

    async def initialize(self) -> None:
        """Initialize the text service."""
        self._ollama_available = model_manager.is_available("text")
        if self._ollama_available:
            logger.info("📝 TextService: using Ollama")
        else:
            logger.warning("📝 TextService: Ollama unavailable, using template fallbacks")

    async def generate_text(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        max_tokens: int = 2048,
        temperature: float = 0.7,
    ) -> dict:
        """Generate text via Ollama or fallback."""
        if self._ollama_available:
            try:
                return await self._ollama_generate(prompt, system_prompt, max_tokens, temperature)
            except Exception as e:
                logger.warning(f"Ollama generation failed: {e}, using fallback")

        return self._fallback_generate(prompt, system_prompt)

    async def _ollama_generate(
        self,
        prompt: str,
        system_prompt: Optional[str],
        max_tokens: int,
        temperature: float,
    ) -> dict:
        """Generate text using Ollama API."""
        import httpx

        payload = {
            "model": config.OLLAMA_MODEL,
            "prompt": prompt,
            "stream": False,
            "options": {
                "num_predict": max_tokens,
                "temperature": temperature,
            },
        }

        if system_prompt:
            payload["system"] = system_prompt

        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                f"{config.OLLAMA_BASE_URL}/api/generate",
                json=payload,
            )
            response.raise_for_status()
            data = response.json()
            return {
                "text": data.get("response", ""),
                "model": config.OLLAMA_MODEL,
                "done": data.get("done", False),
            }

    def _fallback_generate(self, prompt: str, system_prompt: Optional[str] = None) -> dict:
        """Fallback text generation using templates."""
        return {
            "text": f"[FALLBACK] Generated response for prompt: {prompt[:200]}...",
            "model": "template_fallback",
            "done": True,
        }

    # ============================================
    # Hooks Generation
    # ============================================

    async def generate_hooks(
        self,
        niche: str,
        content_type: str,
        language: str = "american_english",
        count: int = 5,
    ) -> dict:
        """Generate viral hooks for YouTube Shorts."""
        system_prompt = (
            "You are an expert YouTube Shorts scriptwriter specializing in American English content. "
            "Create attention-grabbing hooks (first 3 seconds) that stop the scroll. "
            "Each hook should be 1-2 sentences maximum. Make them curious, shocking, or emotional. "
            "Return ONLY a JSON array of strings: [\"hook1\", \"hook2\", ...]"
        )

        prompt = (
            f"Create {count} viral YouTube Shorts hooks for:\n"
            f"Niche: {niche}\n"
            f"Content Type: {content_type}\n"
            f"Language: {language}\n\n"
            f"Each hook must:\n"
            f"- Be 1-2 sentences\n"
            f"- Create immediate curiosity or shock\n"
            f"- Sound natural in American English\n"
            f"- Be different from each other\n\n"
            f"Return ONLY a JSON array of strings."
        )

        if self._ollama_available:
            try:
                result = await self._ollama_generate(prompt, system_prompt, max_tokens=1024, temperature=0.9)
                hooks = self._parse_json_array(result["text"])
                if hooks and len(hooks) >= 2:
                    return {"hooks": hooks[:count]}
            except Exception as e:
                logger.warning(f"Hooks generation via Ollama failed: {e}")

        # Fallback hooks
        return {"hooks": self._fallback_hooks(niche, count)}

    # ============================================
    # Ideas Generation
    # ============================================

    async def generate_ideas(
        self,
        niche: str,
        content_type: str,
        hook: Optional[str] = None,
        language: str = "american_english",
        count: int = 5,
    ) -> dict:
        """Generate video ideas."""
        system_prompt = (
            "You are a creative YouTube Shorts ideator. Generate engaging, specific video ideas "
            "that have high viral potential. Each idea should be 2-3 sentences describing what "
            "the video is about. Return ONLY a JSON array of strings."
        )

        hook_context = f"\nHook to base ideas on: {hook}" if hook else ""

        prompt = (
            f"Generate {count} unique YouTube Short ideas for:\n"
            f"Niche: {niche}\n"
            f"Content Type: {content_type}\n"
            f"Language: {language}{hook_context}\n\n"
            f"Each idea should be 2-3 sentences, specific, and engaging. "
            f"Return ONLY a JSON array of strings."
        )

        if self._ollama_available:
            try:
                result = await self._ollama_generate(prompt, system_prompt, max_tokens=1500, temperature=0.9)
                ideas = self._parse_json_array(result["text"])
                if ideas and len(ideas) >= 2:
                    return {"ideas": ideas[:count]}
            except Exception as e:
                logger.warning(f"Ideas generation via Ollama failed: {e}")

        return {"ideas": self._fallback_ideas(niche, count)}

    # ============================================
    # Script Generation
    # ============================================

    async def generate_script(
        self,
        niche: str,
        content_type: str,
        idea: str,
        hook: str,
        duration: int,
        language: str = "american_english",
        voice_style: str = "auto",
    ) -> dict:
        """Generate a complete short script."""
        approx_words = int((duration / 60) * 150)  # ~150 wpm

        system_prompt = (
            "You are an expert YouTube Shorts scriptwriter. Write conversational, engaging scripts "
            "in natural American English. Use short sentences, simple words, and high retention structure. "
            "Format with sections: [HOOK], [INTRO], [MAIN STORY], [PAYOFF], [CTA]. "
            "Write ONLY the narration text, no scene descriptions."
        )

        prompt = (
            f"Write a YouTube Short script:\n"
            f"Niche: {niche}\n"
            f"Content Type: {content_type}\n"
            f"Idea: {idea}\n"
            f"Hook: {hook}\n"
            f"Target Duration: {duration} seconds (~{approx_words} words)\n"
            f"Language: {language}\n"
            f"Voice Style: {voice_style}\n\n"
            f"Structure:\n"
            f"[HOOK] - The hook you were given\n"
            f"[INTRO] - Quick setup (2-3 sentences)\n"
            f"[MAIN STORY] - Core content, conversational\n"
            f"[PAYOFF] - Conclusion / reveal\n"
            f"[CTA] - Call to action (like, subscribe, comment)\n\n"
            f"Use natural American English, short sentences, conversational tone."
        )

        if self._ollama_available:
            try:
                result = await self._ollama_generate(prompt, system_prompt, max_tokens=2500, temperature=0.8)
                script = result["text"].strip()
                if len(script) > 100:
                    return {"script": script, "word_count": len(script.split())}
            except Exception as e:
                logger.warning(f"Script generation via Ollama failed: {e}")

        return {"script": self._fallback_script(niche, idea, hook, duration), "word_count": approx_words}

    # ============================================
    # Scene Breakdown
    # ============================================

    async def generate_scenes(
        self,
        script: str,
        duration: int,
        visual_style: str,
        niche: str,
    ) -> dict:
        """Break script into scenes with visual prompts."""
        system_prompt = (
            "You are a YouTube Shorts director and visual storyboard artist. "
            "Break the given script into scenes. Each scene needs: scene number, duration, "
            "narration excerpt, visual description, image prompt, video prompt, camera movement, "
            "lighting, transition, emotion. "
            "Return ONLY a JSON object with a 'scenes' array."
        )

        prompt = (
            f"Break this script into scenes for a {duration} second YouTube Short:\n\n"
            f"SCRIPT:\n{script}\n\n"
            f"Visual Style: {visual_style}\n"
            f"Niche: {niche}\n"
            f"Aspect Ratio: 9:16 vertical\n\n"
            f"For each scene provide:\n"
            f"- scene_number\n"
            f"- duration (seconds)\n"
            f"- narration (excerpt from script)\n"
            f"- visual_description (what we see)\n"
            f"- image_prompt (for AI image generation, include style, aspect ratio)\n"
            f"- video_prompt (for AI video generation)\n"
            f"- camera_movement (static, zoom_in, zoom_out, pan_left, pan_right, push, pull, handheld)\n"
            f"- lighting (cinematic, dramatic, soft, hard, natural, neon)\n"
            f"- transition (cut, fade, zoom, swipe, glitch, flash, none)\n"
            f"- emotion (neutral, exciting, scary, funny, dramatic, inspiring, mysterious)\n\n"
            f"Return ONLY JSON: {{\"scenes\": [...]}}"
        )

        if self._ollama_available:
            try:
                result = await self._ollama_generate(prompt, system_prompt, max_tokens=3000, temperature=0.7)
                parsed = self._parse_json_object(result["text"])
                if parsed and "scenes" in parsed and len(parsed["scenes"]) >= 2:
                    return {"scenes": parsed["scenes"]}
            except Exception as e:
                logger.warning(f"Scene breakdown via Ollama failed: {e}")

        return {"scenes": self._fallback_scenes(script, duration, visual_style, niche)}

    # ============================================
    # SEO Generation
    # ============================================

    async def generate_seo(
        self,
        script: str,
        niche: str,
        content_type: str,
        language: str = "american_english",
    ) -> dict:
        """Generate YouTube SEO metadata."""
        system_prompt = (
            "You are a YouTube SEO expert specializing in Shorts. Generate optimized titles, "
            "description, and hashtags. Titles should be 40-70 characters, include keywords, "
            "and create curiosity. Description should be engaging with relevant keywords. "
            "Hashtags should be 5-10 relevant tags. Return ONLY JSON."
        )

        prompt = (
            f"Generate YouTube Shorts SEO for:\n"
            f"Niche: {niche}\n"
            f"Content Type: {content_type}\n"
            f"Language: {language}\n\n"
            f"SCRIPT:\n{script[:1500]}\n\n"
            f"Return JSON with:\n"
            f"- titles: array of 5 strings (optimized titles)\n"
            f"- description: string (2-3 sentences, includes keywords and CTA)\n"
            f"- hashtags: array of 8-10 strings (with #)\n"
            f"- keywords: array of 5-8 relevant keywords\n"
            f"- cta: string (call to action for description end)"
        )

        if self._ollama_available:
            try:
                result = await self._ollama_generate(prompt, system_prompt, max_tokens=1500, temperature=0.8)
                parsed = self._parse_json_object(result["text"])
                if parsed and "titles" in parsed:
                    return parsed
            except Exception as e:
                logger.warning(f"SEO generation via Ollama failed: {e}")

        return self._fallback_seo(niche, content_type, script)

    # ============================================
    # Helper: JSON Parsing
    # ============================================

    def _parse_json_array(self, text: str) -> list:
        """Parse JSON array from LLM response text."""
        import re

        # Try to find JSON array in text
        match = re.search(r'\[.*\]', text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                pass

        # Try to extract items line by line
        items = []
        for line in text.split("\n"):
            line = line.strip()
            # Remove numbering and quotes
            line = re.sub(r'^\d+[\.\)]\s*', '', line)
            line = line.strip('"').strip("'").strip("-").strip()
            if line and len(line) > 5:
                items.append(line)

        return items

    def _parse_json_object(self, text: str) -> Optional[dict]:
        """Parse JSON object from LLM response text."""
        import re

        # Try to find JSON object
        match = re.search(r'\{.*\}', text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                pass

        return None

    # ============================================
    # Fallback Generators
    # ============================================

    def _fallback_hooks(self, niche: str, count: int) -> list:
        """Fallback hook templates."""
        templates = [
            f"You won't believe what happened with {niche}...",
            f"This {niche} secret will change everything.",
            f"Nobody tells you this about {niche}.",
            f"The shocking truth about {niche} revealed.",
            f"Stop doing this with {niche} immediately!",
            f"I tried {niche} for 30 days and here's what happened.",
            f"This {niche} trick went viral for a reason.",
            f"Experts hide this {niche} secret from you.",
        ]
        random.shuffle(templates)
        return templates[:count]

    def _fallback_ideas(self, niche: str, count: int) -> list:
        """Fallback idea templates."""
        templates = [
            f"A fascinating deep dive into {niche} that reveals surprising truths most people never knew existed.",
            f"Top 5 mind-blowing facts about {niche} that will make you see the world differently.",
            f"The incredible story of how {niche} transformed from nothing into a global phenomenon.",
            f"Secrets of {niche} that insiders don't want you to discover, explained in under 60 seconds.",
            f"Why everything you thought you knew about {niche} is completely wrong, and the real truth.",
            f"A day in the life of someone obsessed with {niche} — you won't believe what happens.",
            f"The history of {niche} is way more interesting than your history teacher ever told you.",
        ]
        random.shuffle(templates)
        return templates[:count]

    def _fallback_script(self, niche: str, idea: str, hook: str, duration: int) -> str:
        """Fallback script template."""
        return (
            f"[HOOK]\n{hook}\n\n"
            f"[INTRO]\nHey everyone! What if I told you something about {niche} "
            f"that would completely blow your mind? Stick around, because this is wild.\n\n"
            f"[MAIN STORY]\n{idea}\n\n"
            f"Crazy right? And here's the thing — most people have no idea about this. "
            f"They just go about their lives never questioning what they've been told about {niche}. "
            f"But now YOU know. And knowledge is power.\n\n"
            f"[PAYOFF]\nSo the next time you think about {niche}, remember what you just learned. "
            f"It might just change how you see everything.\n\n"
            f"[CTA]\nIf this blew your mind, smash that like button and subscribe for more. "
            f"Drop a comment below — what do YOU think about this? See you in the next one!"
        )

    def _fallback_scenes(self, script: str, duration: int, visual_style: str, niche: str) -> list:
        """Fallback scene breakdown."""
        num_scenes = max(3, min(8, duration // 5))
        scene_duration = round(duration / num_scenes, 1)

        scenes = []
        for i in range(num_scenes):
            scene = {
                "scene_number": i + 1,
                "duration": scene_duration,
                "narration": f"Scene {i + 1} narration",
                "visual_description": f"Visual representation of {niche}, scene {i + 1}",
                "image_prompt": f"{visual_style} style, {niche}, vertical 9:16, cinematic lighting, high quality, detailed",
                "video_prompt": f"Animated {visual_style} scene showing {niche}, smooth camera movement",
                "camera_movement": "slow_zoom_in" if i % 2 == 0 else "slow_zoom_out",
                "lighting": "cinematic",
                "transition": "fade" if i > 0 else "none",
                "emotion": "engaging",
            }
            scenes.append(scene)
        return scenes

    def _fallback_seo(self, niche: str, content_type: str, script: str) -> dict:
        """Fallback SEO metadata."""
        niche_clean = niche.lower().replace(" ", "").replace("_", "")
        return {
            "titles": [
                f"You Won't Believe This About {niche.title()}!",
                f"The Secret {niche.title()} Nobody Tells You",
                f"{niche.title()}: What They Don't Want You To Know",
                f"Mind-Blowing {niche.title()} Facts #shorts",
                f"This {niche.title()} Changed Everything",
            ],
            "description": (
                f"Discover the incredible truth about {niche} in this short! "
                f"Don't forget to LIKE and SUBSCRIBE for more amazing content. "
                f"#shorts #youtube #youtubeshorts #{niche_clean}"
            ),
            "hashtags": [
                "#shorts", "#youtubeshorts", "#youtube", f"#{niche_clean}",
                f"#{content_type or 'viral'}", "#viral", "#trending", "#ai", "#fyp",
            ],
            "keywords": [niche, content_type, "shorts", "viral", "youtube"],
            "cta": "Like & Subscribe for more!",
        }


# Global text service
text_service = TextService()
