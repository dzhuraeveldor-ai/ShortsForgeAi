"""
Video editing / rendering service for AI Worker.
Handles automatic editing: combining scenes, voice, music, subtitles, transitions, effects.
Uses FFmpeg for all rendering.
"""

import subprocess
import tempfile
from pathlib import Path
from typing import Optional
from loguru import logger

from worker.config import config
from worker.services.model_manager import model_manager
from worker.services.image import image_service
from worker.services.video import video_service
from worker.services.voice import voice_service
from worker.services.stt import stt_service
from worker.services.music import music_service
from worker.utils import generate_id


class EditorService:
    """Service for automatic video editing and rendering."""

    def __init__(self):
        self._available = False

    async def initialize(self) -> None:
        """Initialize editor service."""
        self._available = model_manager.is_available("editing")
        if self._available:
            logger.info("✂️ EditorService: FFmpeg available")
        else:
            logger.warning("✂️ EditorService: FFmpeg unavailable")

    @property
    def available(self) -> bool:
        return self._available

    async def render_short(
        self,
        project_data: dict,
    ) -> dict:
        """
        Full automatic video rendering pipeline.

        project_data should contain:
        - script: str
        - scenes: list of scene dicts
        - duration: int (target total seconds)
        - niche: str
        - content_type: str
        - visual_style: str
        - generation_method: str
        - voice_gender: str
        - voice_style: str
        - language: str
        - subtitles: bool
        """
        if not self._available:
            return {
                "status": "error",
                "error": "FFmpeg not available - cannot render video",
            }

        render_id = generate_id()
        render_dir = config.TEMP_DIR / "renders" / render_id
        render_dir.mkdir(parents=True, exist_ok=True)

        try:
            logger.info(f"✂️ Starting render {render_id}")

            # Extract parameters
            scenes = project_data.get("scenes", [])
            target_duration = project_data.get("duration", 30)
            niche = project_data.get("niche", "general")
            content_type = project_data.get("content_type", "story")
            script = project_data.get("script", "")
            voice_gender = project_data.get("voice_gender", "auto")
            voice_style = project_data.get("voice_style", "auto")
            language = project_data.get("language", "american_english")
            subtitles_enabled = project_data.get("subtitles", True)
            generation_method = project_data.get("generation_method", "images_to_video")

            if not scenes:
                scenes = self._create_default_scenes(target_duration, niche)

            # ============================================
            # Step 1: Generate visuals for each scene
            # ============================================
            logger.info(f"✂️ Render step 1: Generating visuals for {len(scenes)} scenes")
            scene_clips = []

            for i, scene in enumerate(scenes):
                scene_duration = float(scene.get("duration", target_duration / len(scenes)))
                image_prompt = scene.get("image_prompt", f"{niche}, cinematic")
                visual_desc = scene.get("visual_description", "")

                logger.info(f"   Scene {i+1}/{len(scenes)}: {scene_duration}s")

                # Generate image
                image_result = await image_service.generate_image(
                    prompt=image_prompt,
                    width=576,
                    height=1024,
                )
                image_path = image_result.get("image_path")

                if not image_path or not Path(image_path).exists():
                    logger.warning(f"   Scene {i+1}: image generation failed, using placeholder")
                    continue

                # Animate image to video (Ken Burns effect)
                video_result = video_service._create_ken_burns_video(
                    Path(image_path),
                    render_dir / f"scene_{i:02d}.mp4",
                    duration=scene_duration,
                )
                video_path = video_result.get("video_path")

                if video_path and Path(video_path).exists():
                    scene_clips.append({
                        "path": video_path,
                        "duration": scene_duration,
                        "transition": scene.get("transition", "fade"),
                    })

            if not scene_clips:
                return {"status": "error", "error": "Failed to generate any scene clips"}

            # ============================================
            # Step 2: Concatenate scene clips
            # ============================================
            logger.info("✂️ Render step 2: Concatenating scenes")
            concat_video = render_dir / "scenes_concat.mp4"
            self._concatenate_clips(scene_clips, concat_video)

            # ============================================
            # Step 3: Generate voice
            # ============================================
            logger.info("✂️ Render step 3: Generating voice")
            clean_text = self._extract_clean_text(script)
            voice_result = await voice_service.generate_voice(
                text=clean_text,
                gender=voice_gender,
                style=voice_style,
                language=language,
            )
            voice_path = voice_result.get("audio_path")

            # ============================================
            # Step 4: Generate subtitles
            # ============================================
            srt_path = None
            if subtitles_enabled and voice_path and Path(voice_path).exists():
                logger.info("✂️ Render step 4: Generating subtitles")
                sub_result = await stt_service.generate_subtitles(voice_path, language)
                srt_path = sub_result.get("srt_path")

            # ============================================
            # Step 5: Generate music
            # ============================================
            logger.info("✂️ Render step 5: Generating music")
            music_style = music_service.select_music_style(niche, content_type)
            actual_duration = sum(s["duration"] for s in scene_clips)
            music_result = await music_service.generate_music(
                style=music_style,
                duration=actual_duration,
            )
            music_path = music_result.get("audio_path")

            # ============================================
            # Step 6: Final mix and render
            # ============================================
            logger.info("✂️ Render step 6: Final audio mix and render")
            output_path = render_dir / "final_short.mp4"

            self._final_render(
                video_path=concat_video,
                voice_path=voice_path,
                music_path=music_path,
                srt_path=srt_path,
                output_path=output_path,
                duration=actual_duration,
            )

            if not output_path.exists() or output_path.stat().st_size == 0:
                return {"status": "error", "error": "Final render produced empty file"}

            logger.info(f"✂️ Render complete: {output_path} ({output_path.stat().st_size} bytes)")

            return {
                "status": "success",
                "video_path": str(output_path),
                "duration": actual_duration,
                "scenes_count": len(scene_clips),
                "subtitles": subtitles_enabled,
                "music_style": music_style,
                "render_id": render_id,
            }

        except Exception as e:
            logger.error(f"✂️ Render failed: {e}")
            return {"status": "error", "error": str(e)}

    def _create_default_scenes(self, duration: int, niche: str) -> list:
        """Create default scenes if none provided."""
        num_scenes = max(3, min(8, duration // 5))
        scene_duration = duration / num_scenes
        scenes = []
        for i in range(num_scenes):
            scenes.append({
                "scene_number": i + 1,
                "duration": scene_duration,
                "image_prompt": f"cinematic shot of {niche}, vertical 9:16, scene {i+1}, high quality",
                "visual_description": f"Scene {i+1} showing {niche}",
                "transition": "fade",
            })
        return scenes

    def _extract_clean_text(self, script: str) -> str:
        """Extract clean narration text from script."""
        import re
        clean = re.sub(r'\[.*?\]', '', script)
        clean = re.sub(r'\n+', ' ', clean)
        clean = clean.strip()
        return clean[:3000]

    def _concatenate_clips(self, clips: list, output_path: Path) -> None:
        """Concatenate multiple video clips using FFmpeg concat demuxer."""
        if len(clips) == 1:
            # Just copy the single clip
            import shutil
            shutil.copy2(clips[0]["path"], str(output_path))
            return

        # Create concat file list
        list_file = output_path.parent / "concat_list.txt"
        lines = []
        for clip in clips:
            abs_path = Path(clip["path"]).resolve()
            lines.append(f"file '{abs_path}'")
        list_file.write_text("\n".join(lines))

        cmd = [
            config.FFMPEG_PATH, "-y",
            "-f", "concat",
            "-safe", "0",
            "-i", str(list_file),
            "-c", "copy",
            str(output_path),
        ]

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode != 0:
            logger.warning(f"Concat failed: {result.stderr[:200]}")
            # Fallback: re-encode concat
            cmd2 = [
                config.FFMPEG_PATH, "-y",
                "-f", "concat",
                "-safe", "0",
                "-i", str(list_file),
                "-c:v", "libx264",
                "-c:a", "aac",
                str(output_path),
            ]
            subprocess.run(cmd2, capture_output=True, timeout=120)

    def _final_render(
        self,
        video_path: Path,
        voice_path: Optional[str],
        music_path: Optional[str],
        srt_path: Optional[str],
        output_path: Path,
        duration: float,
    ) -> None:
        """
        Final render: mix video + voice + music + subtitles with audio ducking.
        """
        inputs = []
        filter_parts = []
        maps = []

        # Video input
        inputs.extend(["-i", str(video_path)])
        has_audio = False

        # Build audio filter chain
        audio_inputs = []
        audio_idx = 1

        # Voice input
        if voice_path and Path(voice_path).exists():
            inputs.extend(["-i", voice_path])
            audio_inputs.append(f"[{audio_idx}:a]")
            audio_idx += 1
            has_audio = True

        # Music input
        if music_path and Path(music_path).exists():
            inputs.extend(["-i", music_path])
            music_idx = audio_idx
            audio_inputs.append(f"[{audio_idx}:a]")
            audio_idx += 1
            has_audio = True

        # Build filter complex
        filter_complex = []

        if len(audio_inputs) == 2:
            # Voice + Music with audio ducking
            # Sidechain compression: music ducks when voice is present
            filter_complex.append(
                f"{audio_inputs[0]}asplit=2[voice1][voice2];"
                f"{audio_inputs[1]}[music];"
                f"[voice2][music]sidechaincompress=threshold=0.1:ratio=4:attack=0.01:release=0.2[ducked_music];"
                f"[voice1][ducked_music]amix=inputs=2:duration=first:dropout_transition=0.5[aout]"
            )
            maps.extend(["-map", "0:v", "-map", "[aout]"])
        elif len(audio_inputs) == 1:
            # Single audio source
            filter_complex.append(f"{audio_inputs[0]}volume=0.9[aout]")
            maps.extend(["-map", "0:v", "-map", "[aout]"])
        else:
            maps.extend(["-map", "0:v"])

        # Subtitles burn-in
        if srt_path and Path(srt_path).exists():
            # Escape path for FFmpeg filter
            srt_escaped = str(Path(srt_path).resolve()).replace("\\", "\\\\").replace(":", "\\:").replace("'", "'\\''")
            subtitle_filter = (
                f"subtitles='{srt_escaped}':"
                f"force_style='FontName=Arial,FontSize=24,PrimaryColour=&H00FFFFFF,"
                f"OutlineColour=&H00000000,Outline=1,Shadow=0,Alignment=2,"
                f"MarginV=60,Bold=1'"
            )
            if filter_complex:
                # Add to existing filter chain
                filter_complex.append(f"[0:v]{subtitle_filter}[vout]")
                maps = ["-map", "[vout]"] + [m for m in maps if m != "0:v" and not m.startswith("[")]
                if any("aout" in m for m in maps):
                    maps.append("-map")
                    maps.append("[aout]")
            else:
                filter_complex.append(f"[0:v]{subtitle_filter}[vout]")
                maps = ["-map", "[vout]"] + maps

        # Build full command
        cmd = [config.FFMPEG_PATH, "-y"] + inputs

        if filter_complex:
            cmd.extend(["-filter_complex", ";".join(filter_complex)])

        cmd.extend(maps if maps else [])

        # Encoding options
        cmd.extend([
            "-c:v", "libx264",
            "-preset", "medium",
            "-crf", "23",
            "-pix_fmt", "yuv420p",
            "-movflags", "+faststart",
        ])

        if has_audio:
            cmd.extend([
                "-c:a", "aac",
                "-b:a", "128k",
                "-ar", "44100",
            ])
        else:
            cmd.extend(["-an"])

        # Shortest flag if mixing audio of different lengths
        if len(audio_inputs) >= 1:
            cmd.extend(["-shortest"])

        cmd.append(str(output_path))

        logger.debug(f"FFmpeg render command: {' '.join(cmd[:20])}...")
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

        if result.returncode != 0:
            logger.error(f"Final render failed: {result.stderr[-500:]}")
            raise RuntimeError(f"FFmpeg render failed: {result.stderr[:200]}")


# Global editor service
editor_service = EditorService()
