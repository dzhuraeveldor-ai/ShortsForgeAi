"""
Image generation service for AI Worker.
Uses Diffusers (Stable Diffusion) when available, with fallback placeholder.
"""

import base64
from pathlib import Path
from typing import Optional
from loguru import logger

from worker.config import config
from worker.services.model_manager import model_manager
from worker.utils import generate_id


class ImageService:
    """Service for AI image generation."""

    def __init__(self):
        self._pipe = None
        self._available = False

    async def initialize(self) -> None:
        """Initialize image generation pipeline."""
        self._available = model_manager.is_available("image")
        if self._available:
            logger.info("🖼 ImageService: Diffusers available (models loaded on demand)")
        else:
            logger.warning("🖼 ImageService: Diffusers unavailable, using placeholder mode")

    async def generate_image(
        self,
        prompt: str,
        negative_prompt: Optional[str] = None,
        width: int = 576,
        height: int = 1024,
        num_inference_steps: int = 20,
    ) -> dict:
        """Generate an image and return path and metadata."""
        output_dir = config.TEMP_DIR / "images"
        output_dir.mkdir(parents=True, exist_ok=True)
        image_id = generate_id()
        output_path = output_dir / f"{image_id}.png"

        if self._available:
            try:
                return await self._generate_with_diffusers(
                    prompt, negative_prompt, width, height,
                    num_inference_steps, output_path,
                )
            except Exception as e:
                logger.warning(f"Diffusers generation failed: {e}, using placeholder")

        # Fallback: create a simple colored placeholder image
        return self._create_placeholder(prompt, width, height, output_path)

    async def _generate_with_diffusers(
        self,
        prompt: str,
        negative_prompt: Optional[str],
        width: int,
        height: int,
        num_inference_steps: int,
        output_path: Path,
    ) -> dict:
        """Generate image using Stable Diffusion pipeline."""
        import torch
        from diffusers import StableDiffusionXLPipeline, StableDiffusionPipeline

        # Load pipeline if not loaded
        if self._pipe is None:
            try:
                # Try SDXL first
                model_id = "stabilityai/stable-diffusion-xl-base-1.0"
                self._pipe = StableDiffusionXLPipeline.from_pretrained(
                    model_id,
                    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
                    variant="fp16" if torch.cuda.is_available() else None,
                    use_safetensors=True,
                )
                if torch.cuda.is_available():
                    self._pipe = self._pipe.to("cuda")
                elif hasattr(self._pipe, "to"):
                    self._pipe = self._pipe.to("cpu")
            except Exception as e:
                logger.warning(f"SDXL not available, trying SD 1.5: {e}")
                model_id = "runwayml/stable-diffusion-v1-5"
                self._pipe = StableDiffusionPipeline.from_pretrained(
                    model_id,
                    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
                )
                if torch.cuda.is_available():
                    self._pipe = self._pipe.to("cuda")

        # Generate
        generator = torch.Generator("cuda" if torch.cuda.is_available() else "cpu").manual_seed(
            abs(hash(prompt)) % (2**32)
        )

        result = self._pipe(
            prompt=prompt,
            negative_prompt=negative_prompt or "",
            width=width,
            height=height,
            num_inference_steps=num_inference_steps,
            generator=generator,
        )

        image = result.images[0]
        image.save(output_path)

        return {
            "image_path": str(output_path),
            "width": width,
            "height": height,
            "prompt": prompt,
            "model": "stable_diffusion",
            "format": "png",
        }

    def _create_placeholder(
        self,
        prompt: str,
        width: int,
        height: int,
        output_path: Path,
    ) -> dict:
        """Create a simple colored placeholder image."""
        try:
            from PIL import Image, ImageDraw, ImageFont

            # Generate color from prompt hash
            color_seed = abs(hash(prompt))
            r = (color_seed & 0xFF0000) >> 16
            g = (color_seed & 0x00FF00) >> 8
            b = color_seed & 0x0000FF

            # Create gradient-ish image
            image = Image.new("RGB", (width, height), (r // 2, g // 2, b // 2))
            draw = ImageDraw.Draw(image)

            # Draw some geometric shapes
            for i in range(5):
                x1 = (color_seed * (i + 1)) % width
                y1 = (color_seed * (i + 2)) % height
                x2 = x1 + width // 3
                y2 = y1 + height // 3
                draw.rectangle([x1, y1, x2, y2], fill=(r, g, b, 128), outline=(255, 255, 255))

            # Draw text
            try:
                font = ImageFont.load_default()
                text = f"AI Generated\nPlaceholder\n{width}x{height}"
                draw.text((width // 4, height // 3), text, fill=(255, 255, 255), font=font)
            except Exception:
                pass

            image.save(output_path)

            return {
                "image_path": str(output_path),
                "width": width,
                "height": height,
                "prompt": prompt,
                "model": "placeholder",
                "format": "png",
                "note": "Placeholder image - install diffusers for real AI generation",
            }

        except Exception as e:
            logger.error(f"Failed to create placeholder: {e}")
            # Create an empty file marker
            output_path.touch()
            return {
                "image_path": str(output_path),
                "width": width,
                "height": height,
                "prompt": prompt,
                "model": "empty",
                "format": "png",
                "error": str(e),
            }


# Global image service
image_service = ImageService()
