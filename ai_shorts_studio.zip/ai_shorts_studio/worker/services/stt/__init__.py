"""
STT / Subtitles service for AI Worker.
Uses Whisper for speech-to-text and subtitle generation.
"""

from pathlib import Path
from typing import Optional
from loguru import logger

from worker.config import config
from worker.services.model_manager import model_manager
from worker.utils import generate_id


class STTService:
    """Service for speech-to-text and subtitle generation."""

    def __init__(self):
        self._model = None
        self._available = False

    async def initialize(self) -> None:
        """Initialize Whisper model."""
        self._available = model_manager.is_available("stt")
        if self._available:
            logger.info(f"📝 STTService: Whisper available (model: {config.WHISPER_MODEL})")
        else:
            logger.warning("📝 STTService: Whisper unavailable")

    def _load_model(self):
        """Lazy-load Whisper model."""
        if self._model is None and self._available:
            import whisper
            self._model = whisper.load_model(config.WHISPER_MODEL)
        return self._model

    async def generate_subtitles(
        self,
        audio_path: str,
        language: str = "auto",
    ) -> dict:
        """Generate subtitles from audio file."""
        output_dir = config.TEMP_DIR / "subtitles"
        output_dir.mkdir(parents=True, exist_ok=True)
        sub_id = generate_id()

        srt_path = output_dir / f"{sub_id}.srt"
        vtt_path = output_dir / f"{sub_id}.vtt"

        if not self._available:
            return self._create_fallback_subtitles(audio_path, srt_path, vtt_path)

        try:
            model = self._load_model()
            if model is None:
                return self._create_fallback_subtitles(audio_path, srt_path, vtt_path)

            # Transcribe
            result = model.transcribe(
                audio_path,
                language=None if language == "auto" else language,
                word_timestamps=True,
            )

            segments = result.get("segments", [])
            detected_language = result.get("language", "en")

            # Generate SRT
            srt_content = self._segments_to_srt(segments)
            srt_path.write_text(srt_content, encoding="utf-8")

            # Generate VTT
            vtt_content = self._segments_to_vtt(segments)
            vtt_path.write_text(vtt_content, encoding="utf-8")

            return {
                "srt_path": str(srt_path),
                "vtt_path": str(vtt_path),
                "language": detected_language,
                "segments_count": len(segments),
                "segments": segments,
                "full_text": result.get("text", ""),
            }

        except Exception as e:
            logger.error(f"Whisper transcription failed: {e}")
            return self._create_fallback_subtitles(audio_path, srt_path, vtt_path)

    def _segments_to_srt(self, segments: list) -> str:
        """Convert Whisper segments to SRT format."""
        lines = []
        for i, seg in enumerate(segments, 1):
            start = self._format_srt_time(seg.get("start", 0))
            end = self._format_srt_time(seg.get("end", 0))
            text = seg.get("text", "").strip()
            lines.append(f"{i}")
            lines.append(f"{start} --> {end}")
            lines.append(text)
            lines.append("")
        return "\n".join(lines)

    def _segments_to_vtt(self, segments: list) -> str:
        """Convert Whisper segments to WebVTT format."""
        lines = ["WEBVTT", ""]
        for seg in segments:
            start = self._format_vtt_time(seg.get("start", 0))
            end = self._format_vtt_time(seg.get("end", 0))
            text = seg.get("text", "").strip()
            lines.append(f"{start} --> {end}")
            lines.append(text)
            lines.append("")
        return "\n".join(lines)

    def _format_srt_time(self, seconds: float) -> str:
        """Format seconds to SRT time: HH:MM:SS,mmm"""
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = int(seconds % 60)
        ms = int((seconds - int(seconds)) * 1000)
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

    def _format_vtt_time(self, seconds: float) -> str:
        """Format seconds to WebVTT time: HH:MM:SS.mmm"""
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = int(seconds % 60)
        ms = int((seconds - int(seconds)) * 1000)
        return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"

    def _create_fallback_subtitles(
        self,
        audio_path: str,
        srt_path: Path,
        vtt_path: Path,
    ) -> dict:
        """Create fallback subtitle files."""
        # Create simple placeholder subtitles
        srt_content = (
            "1\n"
            "00:00:00,000 --> 00:00:05,000\n"
            "[Subtitles placeholder]\n"
            "Install openai-whisper for real subtitle generation.\n\n"
        )
        srt_path.write_text(srt_content, encoding="utf-8")

        vtt_content = (
            "WEBVTT\n\n"
            "00:00:00.000 --> 00:00:05.000\n"
            "[Subtitles placeholder]\n"
            "Install openai-whisper for real subtitle generation.\n"
        )
        vtt_path.write_text(vtt_content, encoding="utf-8")

        return {
            "srt_path": str(srt_path),
            "vtt_path": str(vtt_path),
            "language": "unknown",
            "segments_count": 1,
            "segments": [],
            "full_text": "[Subtitles placeholder]",
            "note": "Placeholder - install openai-whisper for real subtitles",
        }


# Global STT service
stt_service = STTService()
