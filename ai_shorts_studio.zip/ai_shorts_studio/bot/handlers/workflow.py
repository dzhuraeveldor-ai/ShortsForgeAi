"""
Workflow handler for AI Shorts Studio.
Manages the step-by-step short creation process.
"""

from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from database.repositories import LimitRepository, ProjectRepository, JobRepository
from database.models import User
from bot.config import config
from bot.keyboards import (
    niche_keyboard, content_type_keyboard, visual_style_keyboard,
    generation_method_keyboard, duration_keyboard, language_keyboard,
    voice_gender_keyboard, voice_style_keyboard, subtitles_keyboard,
    hook_selection_keyboard, idea_selection_keyboard, script_actions_keyboard,
    preview_keyboard, final_result_keyboard, back_to_menu_keyboard,
    main_menu_keyboard,
)
from bot.services.workflow import workflow_manager, WorkflowState
from bot.services.worker_client import worker_client
from bot.utils import escape_html, parse_callback_data

router = Router()


# ============================================
# FSM States for custom inputs
# ============================================

class WorkflowFSM(StatesGroup):
    waiting_custom_niche = State()
    waiting_other_language = State()


# ============================================
# Start Workflow
# ============================================

async def start_workflow(
    callback: CallbackQuery,
    user: User,
    is_unlimited: bool,
    limit_repo: LimitRepository,
) -> None:
    """Start the short creation workflow - Step 1: Niche selection."""
    # Check if user can create a full short
    can_create = await limit_repo.can_use(user.user_id, "full_shorts", is_unlimited)
    if not can_create:
        remaining = await limit_repo.get_remaining(user.user_id, "full_shorts", is_unlimited)
        await callback.message.edit_text(
            f"⏳ <b>Лимит исчерпан</b>\n\n"
            f"Ваш бесплатный лимит на создание полных Shorts закончился.\n"
            f"Осталось: {remaining} / {limit_repo.DEFAULT_LIMITS['full_shorts']}\n\n"
            f"Лимит обновляется каждые 24 часа.",
            reply_markup=back_to_menu_keyboard(),
            parse_mode="HTML",
        )
        await callback.answer()
        return

    # Reset and create new workflow state
    workflow_manager.reset(user.user_id)
    state = workflow_manager.get(user.user_id)
    state.step = "niche"

    text = (
        f"🔥 <b>Шаг 1 из 9 — Выберите нишу:</b>\n\n"
        f"Выберите категорию для вашего Short:"
    )

    await callback.message.edit_text(
        text,
        reply_markup=niche_keyboard(),
        parse_mode="HTML",
    )
    await callback.answer()


# ============================================
# Niche Selection Handler
# ============================================

@router.callback_query(F.data.startswith("niche:"))
async def callback_niche(
    callback: CallbackQuery,
    user: User,
    state: FSMContext,
    **kwargs,
) -> None:
    """Handle niche selection."""
    _, args = parse_callback_data(callback.data)
    action = args[0] if args else "main"

    wf = workflow_manager.get(user.user_id)

    if action == "more":
        await callback.message.edit_text(
            f"🔥 <b>Шаг 1 из 9 — Дополнительные ниши:</b>",
            reply_markup=niche_keyboard(show_extra=True),
            parse_mode="HTML",
        )
        await callback.answer()
        return

    if action == "custom":
        wf.step = "niche_custom"
        await state.set_state(WorkflowFSM.waiting_custom_niche)
        await callback.message.edit_text(
            f"✏️ <b>Напишите вашу нишу:</b>\n\n"
            f"Например: «Криптовалюты», «Фотография», «Путешествия»",
            reply_markup=back_to_menu_keyboard(),
            parse_mode="HTML",
        )
        await callback.answer()
        return

    # Standard niche selected
    wf.niche = action
    wf.step = "ctype"

    await callback.message.edit_text(
        f"🎬 <b>Шаг 2 из 9 — Тип контента:</b>\n\n"
        f"Ниша: <b>{wf.niche}</b>\n\n"
        f"Какой тип Short создать?",
        reply_markup=content_type_keyboard(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.message(WorkflowFSM.waiting_custom_niche)
async def process_custom_niche(
    message: Message,
    user: User,
    state: FSMContext,
    **kwargs,
) -> None:
    """Process custom niche input."""
    wf = workflow_manager.get(user.user_id)
    wf.custom_niche = message.text.strip()
    wf.niche = "custom"
    wf.step = "ctype"

    await state.clear()

    await message.answer(
        f"🎬 <b>Шаг 2 из 9 — Тип контента:</b>\n\n"
        f"Ниша: <b>{escape_html(wf.custom_niche)}</b>\n\n"
        f"Какой тип Short создать?",
        reply_markup=content_type_keyboard(),
        parse_mode="HTML",
    )


# ============================================
# Content Type Handler
# ============================================

@router.callback_query(F.data.startswith("ctype:"))
async def callback_ctype(
    callback: CallbackQuery,
    user: User,
    **kwargs,
) -> None:
    """Handle content type selection."""
    _, args = parse_callback_data(callback.data)
    wf = workflow_manager.get(user.user_id)
    wf.content_type = args[0] if args else "story"
    wf.step = "vstyle"

    niche_display = wf.custom_niche or wf.niche

    await callback.message.edit_text(
        f"🎨 <b>Шаг 3 из 9 — Визуальный стиль:</b>\n\n"
        f"Ниша: <b>{escape_html(niche_display)}</b>\n"
        f"Тип: <b>{wf.content_type}</b>\n\n"
        f"Выберите визуальный стиль:",
        reply_markup=visual_style_keyboard(),
        parse_mode="HTML",
    )
    await callback.answer()


# ============================================
# Visual Style Handler
# ============================================

@router.callback_query(F.data.startswith("vstyle:"))
async def callback_vstyle(
    callback: CallbackQuery,
    user: User,
    **kwargs,
) -> None:
    """Handle visual style selection."""
    _, args = parse_callback_data(callback.data)
    wf = workflow_manager.get(user.user_id)
    wf.visual_style = args[0] if args else "cinematic"
    wf.step = "genmethod"

    await callback.message.edit_text(
        f"🖼 <b>Шаг 4 из 9 — Способ генерации:</b>\n\n"
        f"Стиль: <b>{wf.visual_style}</b>\n\n"
        f"Выберите способ создания визуалов:\n\n"
        f"<b>🖼 Images</b> — стабильно, быстрее\n"
        f"<b>🎥 AI Video</b> — полноценное видео (требует GPU)\n"
        f"<b>🔄 Images → Video</b> — изображения с анимацией камеры\n"
        f"<b>🎲 Automatic</b> — AI выбирает оптимально",
        reply_markup=generation_method_keyboard(),
        parse_mode="HTML",
    )
    await callback.answer()


# ============================================
# Generation Method Handler
# ============================================

@router.callback_query(F.data.startswith("genmethod:"))
async def callback_genmethod(
    callback: CallbackQuery,
    user: User,
    **kwargs,
) -> None:
    """Handle generation method selection."""
    _, args = parse_callback_data(callback.data)
    wf = workflow_manager.get(user.user_id)
    wf.generation_method = args[0] if args else "auto"
    wf.step = "duration"

    await callback.message.edit_text(
        f"⏱ <b>Шаг 5 из 9 — Длительность:</b>\n\n"
        f"Метод: <b>{wf.generation_method}</b>\n\n"
        f"Выберите длительность видео:",
        reply_markup=duration_keyboard(),
        parse_mode="HTML",
    )
    await callback.answer()


# ============================================
# Duration Handler
# ============================================

@router.callback_query(F.data.startswith("duration:"))
async def callback_duration(
    callback: CallbackQuery,
    user: User,
    **kwargs,
) -> None:
    """Handle duration selection."""
    _, args = parse_callback_data(callback.data)
    wf = workflow_manager.get(user.user_id)
    try:
        wf.duration = int(args[0]) if args else 30
    except ValueError:
        wf.duration = 30
    wf.step = "lang"

    await callback.message.edit_text(
        f"🌎 <b>Шаг 6 из 9 — Язык:</b>\n\n"
        f"Длительность: <b>{wf.duration} сек</b>\n\n"
        f"Выберите язык:",
        reply_markup=language_keyboard(),
        parse_mode="HTML",
    )
    await callback.answer()


# ============================================
# Language Handler
# ============================================

@router.callback_query(F.data.startswith("lang:"))
async def callback_lang(
    callback: CallbackQuery,
    user: User,
    **kwargs,
) -> None:
    """Handle language selection."""
    _, args = parse_callback_data(callback.data)
    wf = workflow_manager.get(user.user_id)
    wf.language = args[0] if args else "american_english"
    wf.step = "vgender"

    await callback.message.edit_text(
        f"🎙 <b>Шаг 7 из 9 — Голос:</b>\n\n"
        f"Язык: <b>{wf.language}</b>\n\n"
        f"Выберите голос:",
        reply_markup=voice_gender_keyboard(),
        parse_mode="HTML",
    )
    await callback.answer()


# ============================================
# Voice Gender Handler
# ============================================

@router.callback_query(F.data.startswith("vgender:"))
async def callback_vgender(
    callback: CallbackQuery,
    user: User,
    **kwargs,
) -> None:
    """Handle voice gender selection."""
    _, args = parse_callback_data(callback.data)
    wf = workflow_manager.get(user.user_id)
    wf.voice_gender = args[0] if args else "auto"
    wf.step = "vstyle_voice"

    await callback.message.edit_text(
        f"🎙 <b>Шаг 8 из 9 — Стиль озвучки:</b>\n\n"
        f"Голос: <b>{wf.voice_gender}</b>\n\n"
        f"Выберите стиль озвучки:",
        reply_markup=voice_style_keyboard(),
        parse_mode="HTML",
    )
    await callback.answer()


# ============================================
# Voice Style Handler
# ============================================

@router.callback_query(F.data.startswith("vstyle_voice:"))
async def callback_vstyle_voice(
    callback: CallbackQuery,
    user: User,
    **kwargs,
) -> None:
    """Handle voice style selection."""
    _, args = parse_callback_data(callback.data)
    wf = workflow_manager.get(user.user_id)
    wf.voice_style = args[0] if args else "auto"
    wf.step = "subs"

    await callback.message.edit_text(
        f"📝 <b>Шаг 9 из 9 — Субтитры:</b>\n\n"
        f"Стиль озвучки: <b>{wf.voice_style}</b>\n\n"
        f"Добавить субтитры?\n\n"
        f"<i>Стиль субтитров будет автоматически подобран под вашу нишу.</i>",
        reply_markup=subtitles_keyboard(),
        parse_mode="HTML",
    )
    await callback.answer()


# ============================================
# Subtitles Handler
# ============================================

@router.callback_query(F.data.startswith("subs:"))
async def callback_subs(
    callback: CallbackQuery,
    user: User,
    is_unlimited: bool,
    limit_repo: LimitRepository,
    **kwargs,
) -> None:
    """Handle subtitles selection and move to hook generation."""
    _, args = parse_callback_data(callback.data)
    wf = workflow_manager.get(user.user_id)
    wf.subtitles = (args[0] == "yes") if args else True
    wf.step = "hook"

    # Check hooks limit
    can_use = await limit_repo.can_use(user.user_id, "hooks", is_unlimited)
    if not can_use:
        await callback.message.edit_text(
            f"⏳ Лимит на генерацию Hooks исчерпан.\n"
            f"Попробуйте позже.",
            reply_markup=back_to_menu_keyboard(),
            parse_mode="HTML",
        )
        await callback.answer()
        return

    await callback.message.edit_text(
        f"🔥 <b>Генерация Hooks...</b>\n\n"
        f"AI создаёт 5 вариантов Hooks для вашего Short...",
        parse_mode="HTML",
    )
    await callback.answer()

    # Generate hooks via worker
    try:
        niche = wf.get_effective_niche()
        result = await worker_client.generate_hooks(
            niche=niche,
            content_type=wf.content_type,
            language=wf.language,
            count=5,
        )

        if result.get("status") == "error":
            raise Exception(result.get("error", "Unknown error"))

        hooks = result.get("result", {}).get("hooks", [])
        if not hooks:
            # Fallback hooks
            hooks = [
                f"You won't believe what happened next...",
                f"This secret changed everything...",
                f"Nobody talks about this...",
                f"The truth will shock you...",
                f"Stop doing this immediately...",
            ]

        wf.hooks = hooks
        await limit_repo.increment(user.user_id, "hooks", is_unlimited)

        # Display hooks
        text = f"🔥 <b>Выберите Hook:</b>\n\n"
        for i, hook in enumerate(hooks, 1):
            text += f"<b>Hook {i}:</b>\n{escape_html(str(hook))}\n\n"

        await callback.message.edit_text(
            text,
            reply_markup=hook_selection_keyboard(len(hooks)),
            parse_mode="HTML",
        )

    except Exception as e:
        logger.error(f"Hook generation failed: {e}")
        # Fallback: show simple hooks
        fallback_hooks = [
            "You won't believe what happened next...",
            "This secret changed everything...",
            "Nobody talks about this...",
            "The truth will shock you...",
            "Stop doing this immediately...",
        ]
        wf.hooks = fallback_hooks

        text = f"🔥 <b>Выберите Hook:</b>\n\n"
        for i, hook in enumerate(fallback_hooks, 1):
            text += f"<b>Hook {i}:</b>\n{escape_html(hook)}\n\n"

        await callback.message.edit_text(
            text + f"\n<i>⚠️ Используются стандартные шаблоны (Worker недоступен)</i>",
            reply_markup=hook_selection_keyboard(len(fallback_hooks)),
            parse_mode="HTML",
        )


# ============================================
# Hook Selection Handler
# ============================================

@router.callback_query(F.data.startswith("hook:"))
async def callback_hook(
    callback: CallbackQuery,
    user: User,
    is_unlimited: bool,
    limit_repo: LimitRepository,
    **kwargs,
) -> None:
    """Handle hook selection."""
    _, args = parse_callback_data(callback.data)
    action = args[0] if args else "select"
    wf = workflow_manager.get(user.user_id)

    if action == "select" and len(args) > 1:
        try:
            idx = int(args[1]) - 1
            if 0 <= idx < len(wf.hooks):
                wf.selected_hook = str(wf.hooks[idx])
                wf.step = "idea"
                await _generate_ideas(callback, user, wf, is_unlimited, limit_repo)
            else:
                await callback.answer("❌ Неверный выбор", show_alert=True)
        except ValueError:
            await callback.answer("❌ Неверный выбор", show_alert=True)

    elif action == "ai_choose":
        if wf.hooks:
            import random
            wf.selected_hook = str(random.choice(wf.hooks))
            wf.step = "idea"
            await _generate_ideas(callback, user, wf, is_unlimited, limit_repo)

    elif action == "regenerate":
        await callback_subs(
            callback, user, is_unlimited, limit_repo,
            subs="yes" if wf.subtitles else "no",
            **kwargs,
        )

    await callback.answer()


async def _generate_ideas(
    callback: CallbackQuery,
    user: User,
    wf: WorkflowState,
    is_unlimited: bool,
    limit_repo: LimitRepository,
) -> None:
    """Generate ideas after hook selection."""
    can_use = await limit_repo.can_use(user.user_id, "ideas", is_unlimited)
    if not can_use:
        await callback.message.edit_text(
            f"⏳ Лимит на генерацию идей исчерпан.",
            reply_markup=back_to_menu_keyboard(),
            parse_mode="HTML",
        )
        return

    await callback.message.edit_text(
        f"💡 <b>Генерация идей...</b>\n\n"
        f"AI создаёт 5 идей на основе выбранного Hook...",
        parse_mode="HTML",
    )

    try:
        niche = wf.get_effective_niche()
        result = await worker_client.generate_ideas(
            niche=niche,
            content_type=wf.content_type,
            hook=wf.selected_hook,
            language=wf.language,
            count=5,
        )

        if result.get("status") == "error":
            raise Exception(result.get("error", "Unknown"))

        ideas = result.get("result", {}).get("ideas", [])
        if not ideas:
            ideas = [
                f"A fascinating story about {niche} that will surprise everyone.",
                f"Top 5 incredible facts about {niche} you never knew.",
                f"The shocking truth behind {niche} revealed.",
                f"How {niche} completely changed the world.",
                f"Secrets of {niche} that experts hide.",
            ]

        wf.ideas = ideas
        await limit_repo.increment(user.user_id, "ideas", is_unlimited)

        text = f"💡 <b>Выберите идею:</b>\n\n"
        text += f"<b>Hook:</b> {escape_html(str(wf.selected_hook))}\n\n"
        for i, idea in enumerate(ideas, 1):
            text += f"<b>Idea {i}:</b>\n{escape_html(str(idea))}\n\n"

        await callback.message.edit_text(
            text,
            reply_markup=idea_selection_keyboard(len(ideas)),
            parse_mode="HTML",
        )

    except Exception as e:
        logger.error(f"Idea generation failed: {e}")
        niche = wf.get_effective_niche()
        fallback_ideas = [
            f"A fascinating story about {niche} that will surprise everyone.",
            f"Top 5 incredible facts about {niche} you never knew.",
            f"The shocking truth behind {niche} revealed.",
            f"How {niche} completely changed the world.",
            f"Secrets of {niche} that experts hide.",
        ]
        wf.ideas = fallback_ideas

        text = f"💡 <b>Выберите идею:</b>\n\n"
        for i, idea in enumerate(fallback_ideas, 1):
            text += f"<b>Idea {i}:</b>\n{escape_html(idea)}\n\n"

        await callback.message.edit_text(
            text + f"\n<i>⚠️ Используются стандартные шаблоны</i>",
            reply_markup=idea_selection_keyboard(len(fallback_ideas)),
            parse_mode="HTML",
        )


# ============================================
# Idea Selection Handler
# ============================================

@router.callback_query(F.data.startswith("idea:"))
async def callback_idea(
    callback: CallbackQuery,
    user: User,
    is_unlimited: bool,
    limit_repo: LimitRepository,
    **kwargs,
) -> None:
    """Handle idea selection."""
    _, args = parse_callback_data(callback.data)
    action = args[0] if args else "select"
    wf = workflow_manager.get(user.user_id)

    if action == "select" and len(args) > 1:
        try:
            idx = int(args[1]) - 1
            if 0 <= idx < len(wf.ideas):
                wf.selected_idea = str(wf.ideas[idx])
                wf.step = "script"
                await _generate_script(callback, user, wf, is_unlimited, limit_repo)
            else:
                await callback.answer("❌ Неверный выбор", show_alert=True)
        except ValueError:
            await callback.answer("❌ Неверный выбор", show_alert=True)

    elif action == "ai_choose":
        if wf.ideas:
            import random
            wf.selected_idea = str(random.choice(wf.ideas))
            wf.step = "script"
            await _generate_script(callback, user, wf, is_unlimited, limit_repo)

    elif action == "regenerate":
        await _generate_ideas(callback, user, wf, is_unlimited, limit_repo)

    await callback.answer()


async def _generate_script(
    callback: CallbackQuery,
    user: User,
    wf: WorkflowState,
    is_unlimited: bool,
    limit_repo: LimitRepository,
) -> None:
    """Generate script after idea selection."""
    can_use = await limit_repo.can_use(user.user_id, "scripts", is_unlimited)
    if not can_use:
        await callback.message.edit_text(
            f"⏳ Лимит на генерацию сценариев исчерпан.",
            reply_markup=back_to_menu_keyboard(),
            parse_mode="HTML",
        )
        return

    await callback.message.edit_text(
        f"✍️ <b>Генерация сценария...</b>\n\n"
        f"AI создаёт полный сценарий на {wf.duration} секунд...",
        parse_mode="HTML",
    )

    try:
        niche = wf.get_effective_niche()
        result = await worker_client.generate_script(
            niche=niche,
            content_type=wf.content_type,
            idea=wf.selected_idea,
            hook=wf.selected_hook,
            duration=wf.duration,
            language=wf.language,
            voice_style=wf.voice_style,
        )

        if result.get("status") == "error":
            raise Exception(result.get("error", "Unknown"))

        script = result.get("result", {}).get("script", "")
        if not script:
            script = (
                f"[HOOK]\n{wf.selected_hook}\n\n"
                f"[INTRO]\nHey everyone! Today we're diving into something incredible about {niche}.\n\n"
                f"[MAIN STORY]\n{wf.selected_idea}\n\n"
                f"[PAYOFF]\nAnd that's why this matters more than you think.\n\n"
                f"[CTA]\nLike and subscribe for more amazing content!"
            )

        wf.script = script
        await limit_repo.increment(user.user_id, "scripts", is_unlimited)

        text = f"✍️ <b>Сценарий готов:</b>\n\n"
        text += f"<pre>{escape_html(script)}</pre>\n\n"
        text += f"<i>Длительность: ~{wf.duration} сек</i>"

        await callback.message.edit_text(
            text,
            reply_markup=script_actions_keyboard(),
            parse_mode="HTML",
        )

    except Exception as e:
        logger.error(f"Script generation failed: {e}")
        niche = wf.get_effective_niche()
        fallback_script = (
            f"[HOOK]\n{wf.selected_hook}\n\n"
            f"[INTRO]\nHey everyone! Today we're diving into something incredible about {niche}.\n\n"
            f"[MAIN STORY]\n{wf.selected_idea}\n\n"
            f"[PAYOFF]\nAnd that's why this matters more than you think.\n\n"
            f"[CTA]\nLike and subscribe for more amazing content!"
        )
        wf.script = fallback_script

        text = f"✍️ <b>Сценарий (шаблон):</b>\n\n"
        text += f"<pre>{escape_html(fallback_script)}</pre>\n\n"
        text += f"<i>⚠️ Worker недоступен, используется шаблон</i>"

        await callback.message.edit_text(
            text,
            reply_markup=script_actions_keyboard(),
            parse_mode="HTML",
        )


# ============================================
# Script Actions Handler
# ============================================

@router.callback_query(F.data.startswith("script:"))
async def callback_script(
    callback: CallbackQuery,
    user: User,
    is_unlimited: bool,
    limit_repo: LimitRepository,
    project_repo: ProjectRepository,
    **kwargs,
) -> None:
    """Handle script action buttons."""
    _, args = parse_callback_data(callback.data)
    action = args[0] if args else "continue"
    wf = workflow_manager.get(user.user_id)

    if action == "continue":
        wf.step = "preview"

        # Create project in database
        niche = wf.get_effective_niche()
        project = await project_repo.create(
            user_id=user.user_id,
            title=f"{niche} - {wf.content_type}",
            status="draft",
            niche=niche,
            content_type=wf.content_type,
            visual_style=wf.visual_style,
            generation_method=wf.generation_method,
            duration=wf.duration,
            language=wf.language,
            voice_gender=wf.voice_gender,
            voice_style=wf.voice_style,
            subtitles=wf.subtitles,
            hook=wf.selected_hook,
            idea=wf.selected_idea,
            script=wf.script,
        )
        wf.project_id = project.id

        await callback.message.edit_text(
            wf.preview_text(),
            reply_markup=preview_keyboard(),
            parse_mode="HTML",
        )

    elif action == "regenerate":
        await _generate_script(callback, user, wf, is_unlimited, limit_repo)

    elif action in ["edit", "viral", "shorten", "extend"]:
        await callback.answer(
            f"🔄 Функция «{action}» будет доступна в следующих обновлениях.\n"
            f"Нажмите «✅ Continue» чтобы продолжить.",
            show_alert=True,
        )

    await callback.answer()


# ============================================
# Preview Handler
# ============================================

@router.callback_query(F.data.startswith("preview:"))
async def callback_preview(
    callback: CallbackQuery,
    user: User,
    is_unlimited: bool,
    limit_repo: LimitRepository,
    project_repo: ProjectRepository,
    **kwargs,
) -> None:
    """Handle preview confirmation."""
    _, args = parse_callback_data(callback.data)
    action = args[0] if args else "generate"
    wf = workflow_manager.get(user.user_id)

    if action == "generate":
        # Check full short limit
        can_use = await limit_repo.can_use(user.user_id, "full_shorts", is_unlimited)
        if not can_use:
            await callback.message.edit_text(
                f"⏳ Лимит на создание полных Shorts исчерпан.",
                reply_markup=back_to_menu_keyboard(),
                parse_mode="HTML",
            )
            await callback.answer()
            return

        await limit_repo.increment(user.user_id, "full_shorts", is_unlimited)

        # Update project status
        if wf.project_id:
            await project_repo.update(wf.project_id, status="generating")

        wf.step = "generating"

        # Start generation process
        from bot.services.generation import start_generation
        await start_generation(callback, user, wf, project_repo)

    elif action == "change":
        wf.step = "niche"
        await callback.message.edit_text(
            f"🔥 <b>Шаг 1 из 9 — Выберите нишу:</b>",
            reply_markup=niche_keyboard(),
            parse_mode="HTML",
        )

    elif action == "cancel":
        workflow_manager.reset(user.user_id)
        await callback.message.edit_text(
            f"❌ Создание отменено.\n\n"
            f"🎬 <b>AI SHORTS STUDIO</b>\n"
            f"Выберите действие:",
            reply_markup=main_menu_keyboard(),
            parse_mode="HTML",
        )

    await callback.answer()


# ============================================
# Workflow Back Navigation
# ============================================

@router.callback_query(F.data.startswith("workflow:"))
async def callback_workflow_back(
    callback: CallbackQuery,
    user: User,
    **kwargs,
) -> None:
    """Handle back navigation in workflow."""
    _, args = parse_callback_data(callback.data)
    target = args[0] if args else "niche"
    wf = workflow_manager.get(user.user_id)

    back_map = {
        "back_niche": ("niche", niche_keyboard(), "🔥 <b>Шаг 1 из 9 — Выберите нишу:</b>"),
        "back_ctype": ("ctype", content_type_keyboard(), "🎬 <b>Шаг 2 из 9 — Тип контента:</b>"),
        "back_vstyle": ("vstyle", visual_style_keyboard(), "🎨 <b>Шаг 3 из 9 — Визуальный стиль:</b>"),
        "back_genmethod": ("genmethod", generation_method_keyboard(), "🖼 <b>Шаг 4 из 9 — Способ генерации:</b>"),
        "back_duration": ("duration", duration_keyboard(), "⏱ <b>Шаг 5 из 9 — Длительность:</b>"),
        "back_lang": ("lang", language_keyboard(), "🌎 <b>Шаг 6 из 9 — Язык:</b>"),
        "back_vgender": ("vgender", voice_gender_keyboard(), "🎙 <b>Шаг 7 из 9 — Голос:</b>"),
        "back_vstyle_voice": ("vstyle_voice", voice_style_keyboard(), "🎙 <b>Шаг 8 из 9 — Стиль озвучки:</b>"),
        "back_subs": ("subs", subtitles_keyboard(), "📝 <b>Шаг 9 из 9 — Субтитры:</b>"),
    }

    if target in back_map:
        step, keyboard, text = back_map[target]
        wf.step = step
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode="HTML")

    await callback.answer()


# ============================================
# Final Result Handler
# ============================================

@router.callback_query(F.data.startswith("final:"))
async def callback_final(
    callback: CallbackQuery,
    user: User,
    project_repo: ProjectRepository,
    **kwargs,
) -> None:
    """Handle final result actions."""
    _, args = parse_callback_data(callback.data)
    action = args[0] if args else "another"

    if action == "another":
        workflow_manager.reset(user.user_id)
        await callback.message.edit_text(
            f"🎬 <b>AI SHORTS STUDIO</b>\n\n"
            f"Выберите действие:",
            reply_markup=main_menu_keyboard(),
            parse_mode="HTML",
        )

    elif action == "save":
        await callback.answer("✅ Проект сохранён!", show_alert=True)

    elif action == "download":
        await callback.answer("📥 Видео уже отправлено выше!", show_alert=True)

    elif action == "regenerate":
        await callback.answer("🔄 Регенерация... (функция в разработке)", show_alert=True)

    elif action == "edit":
        await callback.answer("✏️ Редактирование... (функция в разработке)", show_alert=True)

    await callback.answer()
