"""
AI Shorts Studio - Telegram Bot Server Main Entry Point.

This is the main Bot Server that handles:
- Telegram communication
- User management
- Workflow navigation
- Project management
- Queue system
- Admin panel

The AI Worker runs separately and connects via API.
"""

import asyncio
import sys
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from loguru import logger

from bot.config import config
from database.database import Database
from bot.handlers.middleware import DatabaseMiddleware, UserMiddleware, LoggingMiddleware
from bot.handlers import commands, workflow, projects, admin
from bot.utils import clean_temp_files


# Configure logging
logger.add(
    config.LOGS_DIR / "bot_{time:YYYY-MM-DD}.log",
    rotation="1 day",
    retention="30 days",
    level="INFO",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {name}:{function}:{line} | {message}",
)

logger.add(
    sys.stdout,
    level="INFO",
    format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan> | {message}",
    colorize=True,
)


async def periodic_cleanup() -> None:
    """Periodic background task: clean temp files, old workflow states."""
    while True:
        try:
            from bot.services.workflow import workflow_manager
            cleaned = workflow_manager.cleanup_old(max_age_hours=24)
            if cleaned > 0:
                logger.info(f"Cleaned up {cleaned} old workflow states")

            files_cleaned = clean_temp_files(older_than_hours=24)
            if files_cleaned > 0:
                logger.info(f"Cleaned up {files_cleaned} old temp files")

        except Exception as e:
            logger.error(f"Periodic cleanup error: {e}")

        await asyncio.sleep(3600)  # Run every hour


async def main() -> None:
    """Main entry point for Bot Server."""
    logger.info("=" * 60)
    logger.info("🎬 AI SHORTS STUDIO - Bot Server")
    logger.info("=" * 60)

    # Validate configuration
    if not config.BOT_TOKEN or config.BOT_TOKEN == "your_bot_token_here":
        logger.error("❌ BOT_TOKEN not set! Please configure .env file.")
        logger.error("   Copy .env.example to .env and set your BOT_TOKEN.")
        sys.exit(1)

    if not config.ADMIN_ID:
        logger.warning("⚠️ ADMIN_ID not set. Admin panel will be unavailable.")

    # Initialize database
    logger.info("🗄 Initializing database...")
    db = Database(config.DATABASE_URL)
    await db.create_tables()
    logger.info("✅ Database ready")

    # Initialize bot and dispatcher
    logger.info("🤖 Initializing Telegram Bot...")
    bot = Bot(
        token=config.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )

    # Store db on bot for convenience
    bot.db = db
    bot.db_session = None  # Will be set per-request by middleware

    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)

    # Register middleware
    dp.update.middleware(DatabaseMiddleware(db))
    dp.update.middleware(UserMiddleware())
    dp.update.middleware(LoggingMiddleware())

    # Register routers
    dp.include_router(commands.router)
    dp.include_router(workflow.router)
    dp.include_router(projects.router)
    dp.include_router(admin.router)

    # Get bot info
    bot_info = await bot.get_me()
    logger.info(f"✅ Bot ready: @{bot_info.username} (ID: {bot_info.id})")
    logger.info(f"👑 Admin ID: {config.ADMIN_ID}")
    logger.info(f"⚙️ Worker URL: {config.WORKER_URL}")
    logger.info(f"💾 Low Resource Mode: {config.LOW_RESOURCE_MODE}")
    logger.info(f"📁 Temp dir: {config.TEMP_DIR}")
    logger.info(f"📁 Storage dir: {config.STORAGE_DIR}")

    # Start periodic cleanup task
    asyncio.create_task(periodic_cleanup())

    # Start polling
    logger.info("🚀 Bot Server started. Waiting for updates...")
    logger.info("=" * 60)
    logger.info("💡 Commands:")
    logger.info("   /start    - Main menu")
    logger.info("   /help     - Help")
    logger.info("   /health   - System status")
    logger.info("   /w1ndeyz  - Admin panel (ADMIN_ID only)")
    logger.info("=" * 60)

    try:
        await dp.start_polling(bot, skip_updates=True)
    except KeyboardInterrupt:
        logger.info("\n👋 Bot Server stopped by user")
    except Exception as e:
        logger.error(f"❌ Bot Server error: {e}")
        raise
    finally:
        await bot.session.close()
        logger.info("🔌 Bot session closed")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("\n👋 Shutdown complete")
