"""
Utility functions for AI Shorts Studio bot.
"""

import os
import random
import string
from datetime import datetime
from pathlib import Path
from typing import Optional

from bot.config import config


def generate_id(length: int = 12) -> str:
    """Generate a random alphanumeric ID."""
    chars = string.ascii_letters + string.digits
    return "".join(random.choice(chars) for _ in range(length))


def get_temp_path(filename: Optional[str] = None, subdir: Optional[str] = None) -> Path:
    """Get a path in the temp directory."""
    directory = config.TEMP_DIR
    if subdir:
        directory = directory / subdir
        directory.mkdir(parents=True, exist_ok=True)
    if filename:
        return directory / filename
    return directory


def get_storage_path(filename: Optional[str] = None, subdir: Optional[str] = None) -> Path:
    """Get a path in the storage directory."""
    directory = config.STORAGE_DIR
    if subdir:
        directory = directory / subdir
        directory.mkdir(parents=True, exist_ok=True)
    if filename:
        return directory / filename
    return directory


def format_duration(seconds: int) -> str:
    """Format duration in seconds to human readable."""
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    secs = seconds % 60
    return f"{minutes}m {secs}s" if secs > 0 else f"{minutes}m"


def format_timestamp(dt: datetime) -> str:
    """Format datetime to human readable string."""
    return dt.strftime("%Y-%m-%d %H:%M UTC")


def safe_filename(name: str) -> str:
    """Convert a string to a safe filename."""
    unsafe_chars = '<>:"/\\|?*'
    for char in unsafe_chars:
        name = name.replace(char, "_")
    name = name.strip().replace(" ", "_")
    return name[:100] or "untitled"


def truncate_text(text: str, max_length: int = 4000) -> str:
    """Truncate text to maximum length with ellipsis."""
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."


def escape_html(text: str) -> str:
    """Escape HTML special characters."""
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def parse_callback_data(data: str) -> tuple[str, list[str]]:
    """Parse callback data into action and arguments."""
    parts = data.split(":")
    action = parts[0]
    args = parts[1:] if len(parts) > 1 else []
    return action, args


def is_admin(user_id: int) -> bool:
    """Check if user is admin."""
    return user_id == config.ADMIN_ID and config.ADMIN_ID != 0


def get_user_status(user_id: int, is_admin_flag: bool, unlimited: bool) -> str:
    """Get user status display string."""
    if is_admin_flag or is_admin(user_id):
        return "👑 Admin"
    if unlimited:
        return "♾️ Unlimited"
    return "👤 Free"


def estimate_word_count(duration_seconds: int, words_per_minute: int = 150) -> int:
    """Estimate target word count based on duration and speaking rate."""
    return int((duration_seconds / 60) * words_per_minute)


def calculate_speech_speed(text: str, target_duration: int) -> float:
    """Calculate speech speed multiplier to fit text into target duration."""
    word_count = len(text.split())
    # Base: 150 words per minute at speed 1.0
    base_duration_minutes = word_count / 150
    base_duration_seconds = base_duration_minutes * 60

    if base_duration_seconds <= 0:
        return 1.0

    speed = base_duration_seconds / target_duration
    # Clamp to reasonable range
    return max(0.8, min(1.3, speed))


def clean_temp_files(older_than_hours: int = 24) -> int:
    """Clean up old temporary files."""
    import shutil
    from datetime import timedelta

    count = 0
    cutoff = datetime.utcnow().timestamp() - (older_than_hours * 3600)

    temp_dir = config.TEMP_DIR
    if not temp_dir.exists():
        return 0

    for item in temp_dir.iterdir():
        try:
            if item.is_file() and item.stat().st_mtime < cutoff:
                item.unlink()
                count += 1
            elif item.is_dir():
                # Check if directory is empty or all files are old
                all_old = True
                dir_count = 0
                for subitem in item.rglob("*"):
                    if subitem.is_file():
                        dir_count += 1
                        if subitem.stat().st_mtime >= cutoff:
                            all_old = False
                            break
                if all_old and dir_count > 0:
                    shutil.rmtree(item)
                    count += dir_count
        except Exception:
            pass

    return count
