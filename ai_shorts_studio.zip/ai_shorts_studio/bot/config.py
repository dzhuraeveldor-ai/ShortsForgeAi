"""
Configuration management for AI Shorts Studio Bot Server.
"""

import os
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv
from pydantic_settings import BaseSettings


# Load .env file
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


class BotConfig(BaseSettings):
    """Bot Server configuration."""

    # Telegram
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
    ADMIN_ID: int = int(os.getenv("ADMIN_ID", "0"))

    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///bot.db")

    # Worker
    WORKER_URL: str = os.getenv("WORKER_URL", "http://localhost:8000")
    WORKER_API_KEY: str = os.getenv("WORKER_API_KEY", "default-worker-key")

    # Resource mode
    LOW_RESOURCE_MODE: bool = os.getenv("LOW_RESOURCE_MODE", "true").lower() == "true"

    # Job limits
    MAX_CONCURRENT_JOBS: int = int(os.getenv("MAX_CONCURRENT_JOBS", "1"))
    MAX_VIDEO_JOBS_PER_USER: int = int(os.getenv("MAX_VIDEO_JOBS_PER_USER", "1"))
    MAX_QUEUE_SIZE: int = int(os.getenv("MAX_QUEUE_SIZE", "20"))

    # Ollama
    OLLAMA_BASE_URL: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    OLLAMA_MODEL: str = os.getenv("OLLAMA_MODEL", "qwen2:7b")

    # Image generation
    IMAGE_DEFAULT_WIDTH: int = int(os.getenv("IMAGE_DEFAULT_WIDTH", "576"))
    IMAGE_DEFAULT_HEIGHT: int = int(os.getenv("IMAGE_DEFAULT_HEIGHT", "1024"))

    # Paths
    TEMP_DIR: Path = BASE_DIR / os.getenv("TEMP_DIR", "temp")
    STORAGE_DIR: Path = BASE_DIR / os.getenv("STORAGE_DIR", "storage")
    LOGS_DIR: Path = BASE_DIR / os.getenv("LOGS_DIR", "logs")

    # FFmpeg
    FFMPEG_PATH: str = os.getenv("FFMPEG_PATH", "ffmpeg")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Ensure directories exist
        self.TEMP_DIR.mkdir(parents=True, exist_ok=True)
        self.STORAGE_DIR.mkdir(parents=True, exist_ok=True)
        self.LOGS_DIR.mkdir(parents=True, exist_ok=True)


# Global config instance
config = BotConfig()


# ============================================
# Niches, Content Types, Visual Styles
# ============================================

NICHES = [
    ("random", "🎲 Random"),
    ("facts", "🧠 Facts"),
    ("horror", "👻 Horror"),
    ("money", "💰 Money"),
    ("science", "🧬 Science"),
    ("history", "🏛 History"),
    ("psychology", "🧠 Psychology"),
    ("relationships", "❤️ Relationships"),
    ("animals", "🐶 Animals"),
    ("ai", "🤖 AI"),
    ("motivation", "💪 Motivation"),
    ("sports", "⚽ Sports"),
    ("movies", "🎬 Movies"),
    ("mystery", "👽 Mystery"),
    ("space", "🚀 Space"),
    ("technology", "📱 Technology"),
    ("reddit", "🗣 Reddit Stories"),
    ("true_crime", "🧟 True Crime"),
    ("luxury", "💎 Luxury"),
    ("gaming", "🎮 Gaming"),
    ("funny", "😂 Funny"),
    ("education", "📚 Education"),
]

EXTRA_NICHES = [
    ("cooking", "🍳 Cooking"),
    ("travel", "✈️ Travel"),
    ("fitness", "🏋️ Fitness"),
    ("music", "🎵 Music"),
    ("art", "🎨 Art"),
    ("fashion", "👗 Fashion"),
    ("cars", "🚗 Cars"),
    ("nature", "🌿 Nature"),
    ("business", "💼 Business"),
    ("philosophy", "📖 Philosophy"),
]

CONTENT_TYPES = [
    ("story", "📖 Story"),
    ("facts", "🤯 Facts"),
    ("educational", "🧠 Educational"),
    ("viral", "🔥 Viral"),
    ("horror", "👻 Horror"),
    ("funny", "😂 Funny"),
    ("top10", "💰 Top 10"),
    ("mystery", "❓ Mystery"),
    ("explainer", "💡 Explainer"),
    ("reddit_story", "🗣 Reddit Story"),
    ("dramatic", "🎭 Dramatic"),
    ("news", "📢 News Style"),
    ("random", "🎲 Random"),
]

VISUAL_STYLES = [
    ("realistic", "📸 Realistic"),
    ("cinematic", "🎬 Cinematic"),
    ("3d", "🧊 3D"),
    ("2d", "🎨 2D"),
    ("cartoon", "✏️ Cartoon"),
    ("anime", "🇯🇵 Anime"),
    ("game", "🎮 Game Style"),
    ("scifi", "🌌 Sci-Fi"),
    ("dark_horror", "👻 Dark Horror"),
    ("illustration", "🖼 Illustration"),
    ("documentary", "📚 Documentary"),
    ("luxury", "💎 Luxury"),
    ("stylized", "🎭 Stylized"),
    ("random", "🎲 Random"),
]

GENERATION_METHODS = [
    ("images", "🖼 Images"),
    ("video", "🎥 AI Video"),
    ("images_to_video", "🔄 Images → Video"),
    ("auto", "🎲 Automatic"),
]

DURATIONS = [
    (10, "10 sec"),
    (15, "15 sec"),
    (30, "30 sec"),
    (45, "45 sec"),
    (60, "60 sec"),
    (90, "90 sec"),
    (120, "120 sec"),
]

LANGUAGES = [
    ("american_english", "🇺🇸 American English"),
    ("british_english", "🇬🇧 British English"),
    ("russian", "🇷🇺 Russian"),
    ("other", "🌍 Other"),
]

VOICE_GENDERS = [
    ("male", "👨 Male"),
    ("female", "👩 Female"),
    ("auto", "🎲 Automatic"),
]

VOICE_STYLES = [
    ("energetic", "🔥 Energetic"),
    ("neutral", "😐 Neutral"),
    ("dramatic", "😱 Dramatic"),
    ("funny", "😂 Funny"),
    ("educational", "🧠 Educational"),
    ("horror", "👻 Horror"),
    ("storytelling", "📖 Storytelling"),
    ("auto", "🎲 Automatic"),
]

SUBTITLE_OPTIONS = [
    ("yes", "✅ Yes"),
    ("no", "❌ No"),
]


# ============================================
# Music Style Mapping
# ============================================

MUSIC_STYLE_MAP = {
    "horror": "dark ambient suspense",
    "motivation": "energetic cinematic",
    "luxury": "elegant ambient",
    "facts": "modern documentary",
    "funny": "light comedic",
    "science": "futuristic ambient",
    "history": "cinematic documentary",
    "gaming": "energetic electronic",
    "animals": "playful emotional",
    "mystery": "suspense dark ambient",
    "ai": "futuristic electronic",
    "storytelling": "cinematic storytelling",
    "money": "corporate ambitious",
    "psychology": "ambient thoughtful",
    "relationships": "emotional piano",
    "space": "ambient cosmic",
    "technology": "modern electronic",
    "true_crime": "tense suspense",
    "education": "light documentary",
    "sports": "energetic driving",
    "movies": "cinematic orchestral",
    "reddit": "storytelling ambient",
}


# ============================================
# Subtitle Style Mapping
# ============================================

SUBTITLE_STYLE_MAP = {
    "horror": "cinematic",
    "facts": "bold_highlight",
    "motivation": "energetic",
    "funny": "dynamic",
    "viral": "bold_impact",
    "educational": "clean_minimal",
    "storytelling": "elegant",
    "mystery": "suspense",
    "gaming": "dynamic_gaming",
    "luxury": "elegant_luxury",
    "science": "tech_clean",
    "ai": "futuristic",
}
