"""
Inline keyboards for AI Shorts Studio Telegram bot.
All user interactions happen through buttons.
"""

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot.config import (
    NICHES, EXTRA_NICHES, CONTENT_TYPES, VISUAL_STYLES,
    GENERATION_METHODS, DURATIONS, LANGUAGES, VOICE_GENDERS,
    VOICE_STYLES, SUBTITLE_OPTIONS,
)


def _build_keyboard(items: list[tuple[str, str]], callback_prefix: str,
                    items_per_row: int = 2, extra_buttons: list[InlineKeyboardButton] | None = None) -> InlineKeyboardMarkup:
    """Helper to build keyboards from (callback_data, label) tuples."""
    builder = InlineKeyboardBuilder()

    for i in range(0, len(items), items_per_row):
        row = items[i:i + items_per_row]
        builder.row(*[
            InlineKeyboardButton(text=label, callback_data=f"{callback_prefix}:{value}")
            for value, label in row
        ])

    if extra_buttons:
        for btn in extra_buttons:
            builder.row(btn)

    return builder.as_markup()


# ============================================
# Main Menu
# ============================================

def main_menu_keyboard() -> InlineKeyboardMarkup:
    """Main menu after /start."""
    buttons = [
        InlineKeyboardButton(text="🎬 Создать Short", callback_data="menu:create_short"),
        InlineKeyboardButton(text="💡 Идеи", callback_data="menu:ideas"),
        InlineKeyboardButton(text="✍️ Сценарий", callback_data="menu:script"),
        InlineKeyboardButton(text="🪝 Hooks", callback_data="menu:hooks"),
        InlineKeyboardButton(text="🖼 Создать изображение", callback_data="menu:image"),
        InlineKeyboardButton(text="🎥 Создать видео", callback_data="menu:video"),
        InlineKeyboardButton(text="🎙 Озвучка", callback_data="menu:voice"),
        InlineKeyboardButton(text="📝 Субтитры", callback_data="menu:subtitles"),
        InlineKeyboardButton(text="🔥 Viral Short", callback_data="menu:viral"),
        InlineKeyboardButton(text="🔍 Анализ видео", callback_data="menu:analyze"),
        InlineKeyboardButton(text="🏷 YouTube SEO", callback_data="menu:seo"),
        InlineKeyboardButton(text="📁 Мои проекты", callback_data="menu:projects"),
        InlineKeyboardButton(text="📊 Статистика", callback_data="menu:stats"),
        InlineKeyboardButton(text="⚙️ Настройки", callback_data="menu:settings"),
        InlineKeyboardButton(text="❓ Помощь", callback_data="menu:help"),
    ]

    builder = InlineKeyboardBuilder()
    for btn in buttons:
        builder.row(btn)
    return builder.as_markup()


# ============================================
# Step 1: Niche Selection
# ============================================

def niche_keyboard(show_extra: bool = False) -> InlineKeyboardMarkup:
    """Niche selection keyboard."""
    niches = NICHES + EXTRA_NICHES if show_extra else NICHES
    builder = InlineKeyboardBuilder()

    for i in range(0, len(niches), 2):
        row = niches[i:i + 2]
        builder.row(*[
            InlineKeyboardButton(text=label, callback_data=f"niche:{value}")
            for value, label in row
        ])

    if not show_extra:
        builder.row(
            InlineKeyboardButton(text="🔄 More Niches", callback_data="niche:more"),
            InlineKeyboardButton(text="✏️ Custom Niche", callback_data="niche:custom"),
        )
    else:
        builder.row(InlineKeyboardButton(text="✏️ Custom Niche", callback_data="niche:custom"))

    builder.row(InlineKeyboardButton(text="⬅️ Назад", callback_data="menu:main"))
    return builder.as_markup()


# ============================================
# Step 2: Content Type
# ============================================

def content_type_keyboard() -> InlineKeyboardMarkup:
    """Content type selection."""
    builder = InlineKeyboardBuilder()
    for i in range(0, len(CONTENT_TYPES), 2):
        row = CONTENT_TYPES[i:i + 2]
        builder.row(*[
            InlineKeyboardButton(text=label, callback_data=f"ctype:{value}")
            for value, label in row
        ])
    builder.row(InlineKeyboardButton(text="⬅️ Назад", callback_data="workflow:back_niche"))
    return builder.as_markup()


# ============================================
# Step 3: Visual Style
# ============================================

def visual_style_keyboard() -> InlineKeyboardMarkup:
    """Visual style selection."""
    builder = InlineKeyboardBuilder()
    for i in range(0, len(VISUAL_STYLES), 2):
        row = VISUAL_STYLES[i:i + 2]
        builder.row(*[
            InlineKeyboardButton(text=label, callback_data=f"vstyle:{value}")
            for value, label in row
        ])
    builder.row(InlineKeyboardButton(text="⬅️ Назад", callback_data="workflow:back_ctype"))
    return builder.as_markup()


# ============================================
# Step 4: Generation Method
# ============================================

def generation_method_keyboard() -> InlineKeyboardMarkup:
    """Generation method selection."""
    builder = InlineKeyboardBuilder()
    for value, label in GENERATION_METHODS:
        builder.row(InlineKeyboardButton(text=label, callback_data=f"genmethod:{value}"))
    builder.row(InlineKeyboardButton(text="⬅️ Назад", callback_data="workflow:back_vstyle"))
    return builder.as_markup()


# ============================================
# Step 5: Duration
# ============================================

def duration_keyboard() -> InlineKeyboardMarkup:
    """Duration selection."""
    builder = InlineKeyboardBuilder()
    for i in range(0, len(DURATIONS), 3):
        row = DURATIONS[i:i + 3]
        builder.row(*[
            InlineKeyboardButton(text=label, callback_data=f"duration:{value}")
            for value, label in row
        ])
    builder.row(InlineKeyboardButton(text="⬅️ Назад", callback_data="workflow:back_genmethod"))
    return builder.as_markup()


# ============================================
# Step 6: Language
# ============================================

def language_keyboard() -> InlineKeyboardMarkup:
    """Language selection."""
    builder = InlineKeyboardBuilder()
    for value, label in LANGUAGES:
        builder.row(InlineKeyboardButton(text=label, callback_data=f"lang:{value}"))
    builder.row(InlineKeyboardButton(text="⬅️ Назад", callback_data="workflow:back_duration"))
    return builder.as_markup()


# ============================================
# Step 7: Voice Gender
# ============================================

def voice_gender_keyboard() -> InlineKeyboardMarkup:
    """Voice gender selection."""
    builder = InlineKeyboardBuilder()
    for value, label in VOICE_GENDERS:
        builder.row(InlineKeyboardButton(text=label, callback_data=f"vgender:{value}"))
    builder.row(InlineKeyboardButton(text="⬅️ Назад", callback_data="workflow:back_lang"))
    return builder.as_markup()


# ============================================
# Step 8: Voice Style
# ============================================

def voice_style_keyboard() -> InlineKeyboardMarkup:
    """Voice style selection."""
    builder = InlineKeyboardBuilder()
    for i in range(0, len(VOICE_STYLES), 2):
        row = VOICE_STYLES[i:i + 2]
        builder.row(*[
            InlineKeyboardButton(text=label, callback_data=f"vstyle_voice:{value}")
            for value, label in row
        ])
    builder.row(InlineKeyboardButton(text="⬅️ Назад", callback_data="workflow:back_vgender"))
    return builder.as_markup()


# ============================================
# Step 9: Subtitles
# ============================================

def subtitles_keyboard() -> InlineKeyboardMarkup:
    """Subtitles toggle."""
    builder = InlineKeyboardBuilder()
    for value, label in SUBTITLE_OPTIONS:
        builder.row(InlineKeyboardButton(text=label, callback_data=f"subs:{value}"))
    builder.row(InlineKeyboardButton(text="⬅️ Назад", callback_data="workflow:back_vstyle_voice"))
    return builder.as_markup()


# ============================================
# Hook Selection
# ============================================

def hook_selection_keyboard(num_hooks: int = 5) -> InlineKeyboardMarkup:
    """Hook selection keyboard."""
    builder = InlineKeyboardBuilder()
    for i in range(1, num_hooks + 1):
        builder.row(InlineKeyboardButton(text=f"🔥 Hook {i}", callback_data=f"hook:select:{i}"))
    builder.row(InlineKeyboardButton(text="🎲 AI Choose", callback_data="hook:ai_choose"))
    builder.row(
        InlineKeyboardButton(text="🔄 Regenerate", callback_data="hook:regenerate"),
        InlineKeyboardButton(text="⬅️ Назад", callback_data="workflow:back_subs"),
    )
    return builder.as_markup()


# ============================================
# Idea Selection
# ============================================

def idea_selection_keyboard(num_ideas: int = 5) -> InlineKeyboardMarkup:
    """Idea selection keyboard."""
    builder = InlineKeyboardBuilder()
    for i in range(1, num_ideas + 1):
        builder.row(InlineKeyboardButton(text=f"💡 Idea {i}", callback_data=f"idea:select:{i}"))
    builder.row(InlineKeyboardButton(text="🎲 AI Choose", callback_data="idea:ai_choose"))
    builder.row(
        InlineKeyboardButton(text="🔄 Regenerate", callback_data="idea:regenerate"),
        InlineKeyboardButton(text="⬅️ Назад", callback_data="workflow:back_hook"),
    )
    return builder.as_markup()


# ============================================
# Script Actions
# ============================================

def script_actions_keyboard() -> InlineKeyboardMarkup:
    """Script action buttons."""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✏️ Edit", callback_data="script:edit"),
        InlineKeyboardButton(text="🔄 Regenerate", callback_data="script:regenerate"),
    )
    builder.row(
        InlineKeyboardButton(text="🔥 Make More Viral", callback_data="script:viral"),
        InlineKeyboardButton(text="✂️ Shorten", callback_data="script:shorten"),
    )
    builder.row(InlineKeyboardButton(text="➕ Extend", callback_data="script:extend"))
    builder.row(
        InlineKeyboardButton(text="✅ Continue", callback_data="script:continue"),
        InlineKeyboardButton(text="⬅️ Назад", callback_data="workflow:back_idea"),
    )
    return builder.as_markup()


# ============================================
# Project Preview
# ============================================

def preview_keyboard() -> InlineKeyboardMarkup:
    """Project preview confirmation."""
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="✅ Generate", callback_data="preview:generate"))
    builder.row(InlineKeyboardButton(text="✏️ Change Settings", callback_data="preview:change"))
    builder.row(InlineKeyboardButton(text="❌ Cancel", callback_data="preview:cancel"))
    return builder.as_markup()


# ============================================
# Final Result
# ============================================

def final_result_keyboard() -> InlineKeyboardMarkup:
    """Final result action buttons."""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🔄 Regenerate", callback_data="final:regenerate"),
        InlineKeyboardButton(text="✏️ Edit", callback_data="final:edit"),
    )
    builder.row(
        InlineKeyboardButton(text="📥 Download", callback_data="final:download"),
        InlineKeyboardButton(text="📁 Save Project", callback_data="final:save"),
    )
    builder.row(InlineKeyboardButton(text="🆕 Create Another", callback_data="final:another"))
    builder.row(InlineKeyboardButton(text="🏠 Главное меню", callback_data="menu:main"))
    return builder.as_markup()


# ============================================
# Projects List
# ============================================

def projects_list_keyboard(projects: list, page: int = 0) -> InlineKeyboardMarkup:
    """Projects list keyboard."""
    builder = InlineKeyboardBuilder()
    for p in projects:
        status_icon = {
            "draft": "📝",
            "generating": "⏳",
            "ready": "✅",
            "failed": "❌",
            "waiting_for_worker": "⏸",
        }.get(p.status, "📄")
        builder.row(InlineKeyboardButton(
            text=f"{status_icon} #{p.id} | {p.title[:30]} | {p.duration}s",
            callback_data=f"project:view:{p.id}"
        ))

    nav_buttons = []
    if page > 0:
        nav_buttons.append(InlineKeyboardButton(text="⬅️ Prev", callback_data=f"projects:page:{page - 1}"))
    nav_buttons.append(InlineKeyboardButton(text="🏠 Главное меню", callback_data="menu:main"))
    builder.row(*nav_buttons)
    return builder.as_markup()


def project_detail_keyboard(project_id: int, status: str) -> InlineKeyboardMarkup:
    """Single project detail keyboard."""
    builder = InlineKeyboardBuilder()

    if status == "ready":
        builder.row(InlineKeyboardButton(text="▶ Preview / Download", callback_data=f"project:download:{project_id}"))

    if status in ["draft", "failed", "ready"]:
        builder.row(InlineKeyboardButton(text="🔄 Regenerate", callback_data=f"project:regenerate:{project_id}"))

    builder.row(
        InlineKeyboardButton(text="✏️ Edit", callback_data=f"project:edit:{project_id}"),
        InlineKeyboardButton(text="🗑 Delete", callback_data=f"project:delete:{project_id}"),
    )
    builder.row(InlineKeyboardButton(text="📁 All Projects", callback_data="menu:projects"))
    builder.row(InlineKeyboardButton(text="🏠 Главное меню", callback_data="menu:main"))
    return builder.as_markup()


# ============================================
# Admin Panel
# ============================================

def admin_panel_keyboard() -> InlineKeyboardMarkup:
    """Admin panel main keyboard."""
    buttons = [
        InlineKeyboardButton(text="📊 Statistics", callback_data="admin:stats"),
        InlineKeyboardButton(text="👥 Users", callback_data="admin:users"),
        InlineKeyboardButton(text="🔎 Find User", callback_data="admin:find_user"),
        InlineKeyboardButton(text="🚫 Block User", callback_data="admin:block_user"),
        InlineKeyboardButton(text="✅ Unblock User", callback_data="admin:unblock_user"),
        InlineKeyboardButton(text="🎁 Give Limits", callback_data="admin:give_limits"),
        InlineKeyboardButton(text="🔄 Reset Limits", callback_data="admin:reset_limits"),
        InlineKeyboardButton(text="♾️ Unlimited", callback_data="admin:unlimited"),
        InlineKeyboardButton(text="📢 Broadcast", callback_data="admin:broadcast"),
        InlineKeyboardButton(text="🤖 AI Worker", callback_data="admin:worker"),
        InlineKeyboardButton(text="🎨 AI Models", callback_data="admin:models"),
        InlineKeyboardButton(text="📋 Queue", callback_data="admin:queue"),
        InlineKeyboardButton(text="❌ Errors", callback_data="admin:errors"),
        InlineKeyboardButton(text="💾 Storage", callback_data="admin:storage"),
        InlineKeyboardButton(text="⚙️ Settings", callback_data="admin:settings"),
        InlineKeyboardButton(text="🏠 Exit Admin", callback_data="menu:main"),
    ]

    builder = InlineKeyboardBuilder()
    for btn in buttons:
        builder.row(btn)
    return builder.as_markup()


def admin_stats_keyboard() -> InlineKeyboardMarkup:
    """Admin stats period selection."""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📅 Today", callback_data="admin:stats:today"),
        InlineKeyboardButton(text="📅 7 Days", callback_data="admin:stats:7d"),
    )
    builder.row(
        InlineKeyboardButton(text="📅 30 Days", callback_data="admin:stats:30d"),
        InlineKeyboardButton(text="📅 All Time", callback_data="admin:stats:all"),
    )
    builder.row(InlineKeyboardButton(text="⬅️ Back", callback_data="admin:panel"))
    return builder.as_markup()


# ============================================
# Error / Retry
# ============================================

def retry_keyboard(action: str) -> InlineKeyboardMarkup:
    """Generic retry keyboard."""
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=f"🔄 Retry", callback_data=f"retry:{action}"))
    builder.row(InlineKeyboardButton(text="🏠 Главное меню", callback_data="menu:main"))
    return builder.as_markup()


# ============================================
# Simple back button
# ============================================

def back_to_menu_keyboard() -> InlineKeyboardMarkup:
    """Simple back to main menu button."""
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="🏠 Главное меню", callback_data="menu:main"))
    return builder.as_markup()
